import fs from "fs";
import path from "path";

let total = 0;

function getSize(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const full = path.join(dir, file);
    const stats = fs.statSync(full);
    if (stats.isDirectory()) {
      getSize(full);
    } else {
      total += stats.size;
    }
  }
}

getSize(".");
console.log("\n📦 TAM ZIP BOYUTU ≈", (total / 1024 / 1024).toFixed(2), "MB\n");