export interface PermessoCity {
  key: string;
  name: string;
  url: string;
}

export const PERMESSO_CITIES: PermessoCity[] = [
  {
    key: 'milano',
    name: 'Milano (Questura)',
    url: 'https://www.questura.gov.it/it/milano',
  },
  {
    key: 'bologna',
    name: 'Bologna (Questura)',
    url: 'https://www.questura.gov.it/it/bologna',
  },
  {
    key: 'torino',
    name: 'Torino (Questura)',
    url: 'https://www.questura.gov.it/it/torino',
  },
  {
    key: 'prenotafacile',
    name: 'PrenotaFacile (Polizia di Stato)',
    url: 'https://www.prenotafacile.poliziadistato.it/',
  },
  {
    key: 'portaleimmigrazione',
    name: 'Portale Immigrazione',
    url: 'https://www.portaleimmigrazione.it/',
  },
  {
    key: 'poste',
    name: 'Poste Italiane - Sportello Amico',
    url: 'https://www.poste.it/sportello-amico.html',
  },
];

export const PERMESSO_GUIDE = {
  it: `**Come prenotare un appuntamento per il Permesso di Soggiorno**

1. **Prepara i documenti necessari:**
   - Passaporto valido
   - Kit giallo del permesso di soggiorno
   - Codice fiscale
   - Marca da bollo (€16)
   - Foto tessera

2. **Accedi al sito di prenotazione:**
   - Visita https://www.prenotazioneps.it/
   - Seleziona la tua città

3. **Compila il modulo:**
   - Inserisci i tuoi dati personali
   - Scegli il tipo di permesso
   - Seleziona una data disponibile

4. **Conferma l'appuntamento:**
   - Riceverai un'email di conferma
   - Stampa la conferma
   - Presentati il giorno dell'appuntamento con tutti i documenti

5. **Il giorno dell'appuntamento:**
   - Arriva 15 minuti prima
   - Porta tutti i documenti originali
   - Porta le fotocopie dei documenti`,

  en: `**How to book an appointment for Residence Permit**

1. **Prepare required documents:**
   - Valid passport
   - Yellow residence permit kit
   - Tax code (codice fiscale)
   - Revenue stamp (€16)
   - Passport photos

2. **Access the booking website:**
   - Visit https://www.prenotazioneps.it/
   - Select your city

3. **Fill in the form:**
   - Enter your personal details
   - Choose permit type
   - Select an available date

4. **Confirm appointment:**
   - You'll receive confirmation email
   - Print the confirmation
   - Attend on appointment day with all documents

5. **On appointment day:**
   - Arrive 15 minutes early
   - Bring all original documents
   - Bring photocopies of documents`,

  tr: `**Oturma İzni Randevusu Nasıl Alınır**

1. **Gerekli belgeleri hazırlayın:**
   - Geçerli pasaport
   - Sarı oturma izni kiti
   - Vergi kodu (codice fiscale)
   - Damga pulu (€16)
   - Vesikalık fotoğraf

2. **Rezervasyon sitesine erişin:**
   - https://www.prenotazioneps.it/ adresini ziyaret edin
   - Şehrinizi seçin

3. **Formu doldurun:**
   - Kişisel bilgilerinizi girin
   - İzin türünü seçin
   - Uygun bir tarih seçin

4. **Randevuyu onaylayın:**
   - Onay e-postası alacaksınız
   - Onayı yazdırın
   - Randevu gününde tüm belgelerle gidin

5. **Randevu günü:**
   - 15 dakika erken gelin
   - Tüm orijinal belgeleri getirin
   - Belgelerin fotokopilerini getirin`,

  ar: `**كيفية حجز موعد للحصول على تصريح الإقامة**

1. **تحضير المستندات المطلوبة:**
   - جواز سفر ساري المفعول
   - طقم تصريح الإقامة الأصفر
   - الرمز الضريبي (codice fiscale)
   - طابع الإيرادات (16 يورو)
   - صور جواز السفر

2. **الدخول إلى موقع الحجز:**
   - قم بزيارة https://www.prenotazioneps.it/
   - اختر مدينتك

3. **املأ النموذج:**
   - أدخل بياناتك الشخصية
   - اختر نوع التصريح
   - اختر تاريخًا متاحًا

4. **تأكيد الموعد:**
   - ستتلقى بريدًا إلكترونيًا للتأكيد
   - اطبع التأكيد
   - احضر في يوم الموعد مع جميع المستندات

5. **يوم الموعد:**
   - احضر قبل 15 دقيقة
   - أحضر جميع المستندات الأصلية
   - أحضر نسخًا من المستندات`,
};
