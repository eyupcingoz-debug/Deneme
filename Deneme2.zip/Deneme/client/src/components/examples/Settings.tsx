import { LanguageProvider } from '@/contexts/LanguageContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import Settings from '../../pages/Settings';

export default function SettingsExample() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <Settings />
      </LanguageProvider>
    </ThemeProvider>
  );
}
