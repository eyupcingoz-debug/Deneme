export interface Dorm {
  city: string;
  name: string;
  university: string;
  gender: 'Male' | 'Female' | 'Mixed';
  roomCapacity: 'Single' | 'Double' | 'Triple';
  priceMin: number;
  priceMax: number;
  applicationLink: string;
  image?: string;
  features?: string[];
}
