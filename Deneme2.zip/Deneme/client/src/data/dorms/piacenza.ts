import { Dorm } from './types';

export const piacenzaDorms: Dorm[] = [
  {
    city: "Piacenza",
    name: "Collegio Morigi",
    university: "Politecnico di Milano - Campus Piacenza",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 250,
    priceMax: 400,
    applicationLink: "https://www.collegiomorigi.it/",
    image: "https://www.collegiomorigi.it/images/collegio.jpg",
    features: ["Wi-Fi", "Study rooms", "Canteen", "Chapel", "Library"]
  },
  {
    city: "Piacenza",
    name: "Residenza Universitaria San Vincenzo",
    university: "Università Cattolica",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 280,
    priceMax: 450,
    applicationLink: "https://piacenza.unicatt.it/residenze",
    image: "https://piacenza.unicatt.it/images/residenze/san-vincenzo.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common areas"]
  },
  {
    city: "Piacenza",
    name: "Casa dello Studente Piacenza",
    university: "Multiple universities",
    gender: "Mixed",
    roomCapacity: "Double",
    priceMin: 200,
    priceMax: 350,
    applicationLink: "https://www.er-go.it/residenze/piacenza",
    image: "https://www.er-go.it/images/residenze/piacenza.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Bike parking"]
  }
];
