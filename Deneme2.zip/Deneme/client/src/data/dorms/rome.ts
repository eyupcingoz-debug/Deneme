import { Dorm } from './types';

export const romeDorms: Dorm[] = [
  {
    city: "Rome",
    name: "Residenza Universitaria Camplus Roma",
    university: "La Sapienza",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 550,
    priceMax: 850,
    applicationLink: "https://www.camplus.it/en/residences/rome/",
    image: "https://www.camplus.it/wp-content/uploads/2019/09/camplus-roma.jpg",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Restaurant"]
  },
  {
    city: "Rome",
    name: "Casa dello Studente",
    university: "La Sapienza",
    gender: "Mixed",
    roomCapacity: "Double",
    priceMin: 250,
    priceMax: 450,
    applicationLink: "https://www.laziodisu.it/",
    image: "https://www.laziodisu.it/images/residenze/casa-studente.jpg",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Laundry"]
  },
  {
    city: "Rome",
    name: "Residenza Universitaria Montesanto",
    university: "Multiple universities",
    gender: "Male",
    roomCapacity: "Single",
    priceMin: 480,
    priceMax: 680,
    applicationLink: "https://www.residenzamontesanto.it/",
    image: "https://www.residenzamontesanto.it/images/struttura.jpg",
    features: ["Wi-Fi", "Chapel", "Library", "Study rooms"]
  },
  {
    city: "Rome",
    name: "Residenza Universitaria Cesare Baronio",
    university: "Multiple universities",
    gender: "Female",
    roomCapacity: "Single",
    priceMin: 450,
    priceMax: 650,
    applicationLink: "https://www.residenzabaronio.it/",
    image: "https://www.residenzabaronio.it/images/esterni.jpg",
    features: ["Wi-Fi", "Study rooms", "Chapel", "Garden"]
  },
  {
    city: "Rome",
    name: "Residenza Tor Vergata",
    university: "Università di Roma Tor Vergata",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 400,
    priceMax: 600,
    applicationLink: "https://www.laziodisu.it/residenze/tor-vergata",
    image: "https://www.laziodisu.it/images/residenze/tor-vergata.jpg",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Sports facilities"]
  },
  {
    city: "Rome",
    name: "Campus X",
    university: "Multiple universities",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 600,
    priceMax: 900,
    applicationLink: "https://www.campusx.it/",
    image: "https://www.campusx.it/images/struttura.jpg",
    features: ["Wi-Fi", "Gym", "Coworking space", "Events room", "Rooftop terrace"]
  }
];
