import { useEffect, useState } from 'react';
import { useLocation, useSearch } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { authAPI } from '@/lib/api';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export default function VerifyEmail() {
  const [, setLocation] = useLocation();
  const searchParams = useSearch();
  const { language } = useLanguage();
  const t = useTranslation(language);
  
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const verifyEmail = async () => {
      const params = new URLSearchParams(searchParams);
      const token = params.get('token');

      if (!token) {
        setStatus('error');
        setMessage(t('noToken') || 'Doğrulama linki geçersiz');
        return;
      }

      try {
        await authAPI.verifyEmail(token);
        setStatus('success');
        setMessage(t('emailVerified') || 'E-posta adresiniz başarıyla doğrulandı!');
      } catch (error: any) {
        setStatus('error');
        setMessage(error.message || t('verificationFailed') || 'Doğrulama başarısız');
      }
    };

    verifyEmail();
  }, [searchParams]);

  return (
    <div className="container max-w-md mx-auto py-12 px-4">
      <Card className="shadow-xl border-2 border-cyan-200">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-cyan-600 to-teal-500 bg-clip-text text-transparent">
            {t('emailVerification') || 'E-posta Doğrulama'}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          {status === 'loading' && (
            <>
              <Loader2 className="h-16 w-16 mx-auto text-cyan-500 animate-spin" />
              <p className="text-gray-600">{t('verifying') || 'Doğrulanıyor...'}</p>
            </>
          )}

          {status === 'success' && (
            <>
              <CheckCircle2 className="h-16 w-16 mx-auto text-green-500" />
              <p className="text-lg font-medium text-green-700">{message}</p>
              <Button
                onClick={() => setLocation('/login')}
                className="bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600"
              >
                {t('goToLogin') || 'Giriş Yap'}
              </Button>
            </>
          )}

          {status === 'error' && (
            <>
              <XCircle className="h-16 w-16 mx-auto text-red-500" />
              <p className="text-lg font-medium text-red-700">{message}</p>
              <Button
                onClick={() => setLocation('/register')}
                variant="outline"
                className="border-cyan-500 text-cyan-600"
              >
                {t('backToRegister') || 'Kayıt Ol'}
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
