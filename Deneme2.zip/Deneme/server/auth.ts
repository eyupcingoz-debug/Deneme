import bcrypt from "bcryptjs";
import { randomUUID } from "crypto";
import { storage } from "./storage";
import type { InsertUser } from "@shared/schema";

const SALT_ROUNDS = 10;

export async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(password, hash);
}

export function generateVerificationToken(): { token: string; expiry: Date } {
  const token = randomUUID();
  const expiry = new Date();
  expiry.setHours(expiry.getHours() + 24); // 24 hour expiry
  return { token, expiry };
}

export async function sendVerificationEmail(email: string, token: string, firstName: string, language: string = 'it') {
  // Get the app URL from environment or construct it
  const appUrl = process.env.REPL_SLUG 
    ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
    : `http://localhost:5000`;
  
  const verificationLink = `${appUrl}/verify-email?token=${token}`;
  
  // Multilingual email content
  const emailContent = {
    it: {
      subject: "Verifica il tuo account - DocuBuddy+",
      greeting: `Ciao ${firstName},`,
      message: "Grazie per esserti registrato! Per attivare il tuo account, clicca sul pulsante qui sotto:",
      button: "Verifica Account",
      expires: "Questo link è valido per 24 ore.",
      ignore: "Se non hai creato questo account, ignora questa email."
    },
    en: {
      subject: "Verify your account - DocuBuddy+",
      greeting: `Hello ${firstName},`,
      message: "Thank you for signing up! To activate your account, click the button below:",
      button: "Verify Account",
      expires: "This link is valid for 24 hours.",
      ignore: "If you didn't create this account, please ignore this email."
    },
    tr: {
      subject: "Hesabını doğrula - DocuBuddy+",
      greeting: `Merhaba ${firstName},`,
      message: "Kayıt olduğunuz için teşekkürler! Hesabınızı aktifleştirmek için aşağıdaki butona tıklayın:",
      button: "Hesabımı Doğrula",
      expires: "Bu link 24 saat geçerlidir.",
      ignore: "Bu hesabı siz oluşturmadıysanız, bu e-postayı görmezden gelin."
    },
    ar: {
      subject: "تحقق من حسابك - DocuBuddy+",
      greeting: `مرحبا ${firstName}،`,
      message: "شكرا لتسجيلك! لتفعيل حسابك، انقر على الزر أدناه:",
      button: "تحقق من الحساب",
      expires: "هذا الرابط صالح لمدة 24 ساعة.",
      ignore: "إذا لم تقم بإنشاء هذا الحساب، يرجى تجاهل هذا البريد الإلكتروني."
    }
  };

  const lang = emailContent[language as keyof typeof emailContent] || emailContent.it;

  // Console log the email (for now, without actual email service)
  console.log(`
    ========================================
    📧 Verification Email
    ========================================
    To: ${email}
    Subject: ${lang.subject}
    
    ${lang.greeting}
    ${lang.message}
    
    ${verificationLink}
    
    ${lang.expires}
    ${lang.ignore}
    ========================================
  `);

  // Note: User dismissed Resend integration, so we'll just log for now
  // In production, they would need to configure email sending manually
  // Store a note in replit.md about this
  
  return { success: true, message: "Verification email logged to console" };
}

export async function sendPasswordResetEmail(email: string, token: string, firstName: string, language: string = 'it') {
  const appUrl = process.env.REPL_SLUG 
    ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
    : `http://localhost:5000`;
  
  const resetLink = `${appUrl}/reset-password?token=${token}`;
  
  const emailContent = {
    it: {
      subject: "Reimposta la tua password - DocuBuddy+",
      greeting: `Ciao ${firstName},`,
      message: "Abbiamo ricevuto una richiesta per reimpostare la tua password. Clicca sul pulsante qui sotto:",
      button: "Reimposta Password",
      expires: "Questo link è valido per 1 ora.",
      ignore: "Se non hai richiesto questa reimpostazione, ignora questa email."
    },
    en: {
      subject: "Reset your password - DocuBuddy+",
      greeting: `Hello ${firstName},`,
      message: "We received a request to reset your password. Click the button below:",
      button: "Reset Password",
      expires: "This link is valid for 1 hour.",
      ignore: "If you didn't request this reset, please ignore this email."
    },
    tr: {
      subject: "Şifreni sıfırla - DocuBuddy+",
      greeting: `Merhaba ${firstName},`,
      message: "Şifrenizi sıfırlama talebi aldık. Aşağıdaki butona tıklayın:",
      button: "Şifreyi Sıfırla",
      expires: "Bu link 1 saat geçerlidir.",
      ignore: "Bu sıfırlama talebini siz yapmadıysanız, bu e-postayı görmezden gelin."
    },
    ar: {
      subject: "إعادة تعيين كلمة المرور - DocuBuddy+",
      greeting: `مرحبا ${firstName}،`,
      message: "تلقينا طلبًا لإعادة تعيين كلمة المرور الخاصة بك. انقر على الزر أدناه:",
      button: "إعادة تعيين كلمة المرور",
      expires: "هذا الرابط صالح لمدة ساعة واحدة.",
      ignore: "إذا لم تطلب هذه الإعادة، يرجى تجاهل هذا البريد الإلكتروني."
    }
  };

  const lang = emailContent[language as keyof typeof emailContent] || emailContent.it;

  console.log(`
    ========================================
    📧 Password Reset Email
    ========================================
    To: ${email}
    Subject: ${lang.subject}
    
    ${lang.greeting}
    ${lang.message}
    
    ${resetLink}
    
    ${lang.expires}
    ${lang.ignore}
    ========================================
  `);

  return { success: true, message: "Password reset email logged to console" };
}
