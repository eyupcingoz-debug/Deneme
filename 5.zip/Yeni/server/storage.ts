import { db } from "./db";
import { users, roommateListings, roomListings, dormitories } from "@shared/schema";
import type { 
  User, 
  InsertUser, 
  RoommateListing, 
  InsertRoommateListing,
  RoomListing,
  InsertRoomListing,
  Dormitory,
  InsertDormitory
} from "@shared/schema";
import { eq, and, or, gte, lte, desc } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  verifyUserEmail(token: string): Promise<User | undefined>;
  
  // Roommate listing methods
  createRoommateListing(listing: InsertRoommateListing): Promise<RoommateListing>;
  getRoommateListings(filters?: any): Promise<RoommateListing[]>;
  getRoommateListingsByUser(userId: string): Promise<RoommateListing[]>;
  deleteRoommateListing(id: string, userId: string): Promise<boolean>;
  
  // Room listing methods
  createRoomListing(listing: InsertRoomListing): Promise<RoomListing>;
  getRoomListings(filters?: any): Promise<RoomListing[]>;
  getRoomListingsByUser(userId: string): Promise<RoomListing[]>;
  deleteRoomListing(id: string, userId: string): Promise<boolean>;
  
  // Dormitory methods
  createDormitory(dormitory: InsertDormitory): Promise<Dormitory>;
  getDormitories(city?: string): Promise<Dormitory[]>;
}

export class DbStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const result = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async verifyUserEmail(token: string): Promise<User | undefined> {
    const user = await db
      .select()
      .from(users)
      .where(eq(users.verificationToken, token))
      .limit(1);

    if (!user[0]) return undefined;

    if (user[0].verificationTokenExpiry && user[0].verificationTokenExpiry < new Date()) {
      return undefined; // Token expired
    }

    const updated = await db
      .update(users)
      .set({
        isVerified: true,
        verificationToken: null,
        verificationTokenExpiry: null,
        updatedAt: new Date()
      })
      .where(eq(users.id, user[0].id))
      .returning();

    return updated[0];
  }

  // Roommate listing methods
  async createRoommateListing(listing: InsertRoommateListing): Promise<RoommateListing> {
    const result = await db.insert(roommateListings).values(listing as any).returning();
    return result[0];
  }

  async getRoommateListings(filters?: any): Promise<RoommateListing[]> {
    let query = db.select().from(roommateListings);
    
    const conditions = [];
    if (filters?.city) {
      conditions.push(eq(roommateListings.city, filters.city));
    }
    if (filters?.nationality) {
      conditions.push(eq(roommateListings.nationality, filters.nationality));
    }
    if (filters?.budgetMax) {
      conditions.push(lte(roommateListings.budgetMin, filters.budgetMax));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }
    
    return await query.orderBy(desc(roommateListings.createdAt));
  }

  async getRoommateListingsByUser(userId: string): Promise<RoommateListing[]> {
    return await db
      .select()
      .from(roommateListings)
      .where(eq(roommateListings.userId, userId))
      .orderBy(desc(roommateListings.createdAt));
  }

  async deleteRoommateListing(id: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(roommateListings)
      .where(and(eq(roommateListings.id, id), eq(roommateListings.userId, userId)))
      .returning();
    return result.length > 0;
  }

  // Room listing methods
  async createRoomListing(listing: InsertRoomListing): Promise<RoomListing> {
    const result = await db.insert(roomListings).values(listing as any).returning();
    return result[0];
  }

  async getRoomListings(filters?: any): Promise<RoomListing[]> {
    let query = db.select().from(roomListings);
    
    const conditions = [];
    if (filters?.city) {
      conditions.push(eq(roomListings.city, filters.city));
    }
    if (filters?.roomType) {
      conditions.push(eq(roomListings.roomType, filters.roomType));
    }
    if (filters?.maxRent) {
      conditions.push(lte(roomListings.rent, filters.maxRent));
    }
    if (filters?.preferredNationality) {
      conditions.push(
        or(
          eq(roomListings.preferredNationality, filters.preferredNationality),
          eq(roomListings.preferredNationality, null) as any
        ) as any
      );
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }
    
    return await query.orderBy(desc(roomListings.createdAt));
  }

  async getRoomListingsByUser(userId: string): Promise<RoomListing[]> {
    return await db
      .select()
      .from(roomListings)
      .where(eq(roomListings.userId, userId))
      .orderBy(desc(roomListings.createdAt));
  }

  async deleteRoomListing(id: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(roomListings)
      .where(and(eq(roomListings.id, id), eq(roomListings.userId, userId)))
      .returning();
    return result.length > 0;
  }

  // Dormitory methods
  async createDormitory(dormitory: InsertDormitory): Promise<Dormitory> {
    const result = await db.insert(dormitories).values(dormitory as any).returning();
    return result[0];
  }

  async getDormitories(city?: string): Promise<Dormitory[]> {
    if (city) {
      return await db
        .select()
        .from(dormitories)
        .where(eq(dormitories.city, city))
        .orderBy(desc(dormitories.createdAt));
    }
    return await db.select().from(dormitories).orderBy(desc(dormitories.createdAt));
  }
}

export const storage = new DbStorage();
