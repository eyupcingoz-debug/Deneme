import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface DocumentAnalysisResult {
  isValid: boolean;
  documentType: string;
  confidence: number;
  keywords: string[];
  relatedFlow?: string;
  message: string;
}

const DOCUMENT_TYPES = {
  isee: {
    keywords: ['ISEE', 'DSU', 'dichiarazione sostitutiva unica', 'INPS', 'nucleo familiare', 'reddito', 'patrimonio', 'università', 'borsa di studio'],
    variants: ['ISEE Università', 'ISEE Ordinario', 'ISEE Corrente']
  },
  permesso: {
    keywords: ['permesso di soggiorno', 'questura', 'residence permit', 'kit giallo', 'polizia di stato', 'marca da bollo', 'immigrazione', 'stranieri'],
    variants: ['Prima Richiesta', 'Rinnovo', 'Primo Permesso']
  },
  firstPermesso: {
    keywords: ['primo permesso', 'first residence permit', 'prima richiesta', 'kit giallo', 'arrivo in italia', '8 giorni'],
    variants: ['Prima Richiesta Permesso']
  },
  codiceFiscale: {
    keywords: ['codice fiscale', 'tax code', 'agenzia delle entrate', 'tessera sanitaria', 'CF'],
    variants: ['Codice Fiscale']
  },
  spid: {
    keywords: ['SPID', 'identità digitale', 'digital identity', 'PosteID', 'Aruba', 'Infocert', 'credenziali'],
    variants: ['SPID Livello 1', 'SPID Livello 2', 'SPID Livello 3']
  },
  tesseraSanitaria: {
    keywords: ['tessera sanitaria', 'health card', 'ASL', 'medico di base', 'sistema sanitario', 'codice fiscale'],
    variants: ['Tessera Sanitaria']
  },
  cartaIdentita: {
    keywords: ['carta d\'identità', 'identity card', 'documento di identità', 'comune', 'anagrafe'],
    variants: ['Carta d\'Identità Elettronica', 'CIE']
  },
  universita: {
    keywords: ['università', 'university', 'immatricolazione', 'iscrizione', 'enrollment', 'studente', 'libretto'],
    variants: ['Immatricolazione', 'Iscrizione']
  },
  dsu: {
    keywords: ['DSU', 'borsa di studio', 'scholarship', 'diritto allo studio', 'università', 'tasse universitarie'],
    variants: ['DSU', 'Borsa di Studio']
  },
  patente: {
    keywords: ['patente', 'driver license', 'motorizzazione', 'conversione patente', 'guida'],
    variants: ['Conversione Patente', 'Patente Italiana']
  },
  anagrafe: {
    keywords: ['anagrafe', 'residenza', 'domicilio', 'comune', 'dichiarazione di residenza'],
    variants: ['Residenza', 'Cambio Residenza']
  }
};

export async function analyzeDocument(
  imageBase64: string,
  language: string = 'it'
): Promise<DocumentAnalysisResult> {
  try {
    if (!process.env.GEMINI_API_KEY) {
      return {
        isValid: false,
        documentType: 'unknown',
        confidence: 0,
        keywords: [],
        message: language === 'tr' 
          ? 'API anahtarı yapılandırılmadı.' 
          : 'Chiave API non configurata.'
      };
    }

    const prompt = language === 'tr' 
      ? `Bu İtalya'da öğrenciler için bürokratik belge analizcidir. Yüklenen belgeyi analiz et ve şunları belirle:

1. Belge türü (ISEE, Permesso di Soggiorno, Codice Fiscale, SPID, Tessera Sanitaria, vb.)
2. Belge geçerli mi? (Süresi dolmuş mu? Eksik bilgi var mı?)
3. Hangi işlem için uygun? (İlk başvuru, yenileme, vb.)
4. Güven yüzdesi (0-100)
5. Belgede bulunan anahtar kelimeler

ÖNEMLİ: Belge analiz edilemeyen bir format ise veya metin içermiyorsa, documentType'ı 'unknown' olarak belirt.

Yanıtı SADECE aşağıdaki JSON formatında ver:
{
  "documentType": "isee|permesso|firstPermesso|codiceFiscale|spid|tesseraSanitaria|cartaIdentita|universita|dsu|patente|anagrafe|unknown",
  "isValid": true/false,
  "confidence": 0-100,
  "keywords": ["anahtar", "kelime", "listesi"],
  "variant": "belge alt türü (örn: Rinnovo, Prima Richiesta)",
  "notes": "ek notlar veya uyarılar"
}`
      : `Questo è un analizzatore di documenti burocratici per studenti in Italia. Analizza il documento caricato e determina:

1. Tipo di documento (ISEE, Permesso di Soggiorno, Codice Fiscale, SPID, Tessera Sanitaria, ecc.)
2. Il documento è valido? (È scaduto? Mancano informazioni?)
3. Per quale procedura è adatto? (Prima richiesta, rinnovo, ecc.)
4. Percentuale di confidenza (0-100)
5. Parole chiave trovate nel documento

IMPORTANTE: Se il documento non può essere analizzato o non contiene testo, imposta documentType come 'unknown'.

Rispondi SOLO nel seguente formato JSON:
{
  "documentType": "isee|permesso|firstPermesso|codiceFiscale|spid|tesseraSanitaria|cartaIdentita|universita|dsu|patente|anagrafe|unknown",
  "isValid": true/false,
  "confidence": 0-100,
  "keywords": ["lista", "parole", "chiave"],
  "variant": "variante del documento (es: Rinnovo, Prima Richiesta)",
  "notes": "note aggiuntive o avvisi"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash-exp",
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inlineData: {
                mimeType: imageBase64.startsWith('data:image/png') ? 'image/png' : 
                          imageBase64.startsWith('data:image/jpeg') || imageBase64.startsWith('data:image/jpg') ? 'image/jpeg' :
                          imageBase64.startsWith('data:application/pdf') ? 'application/pdf' : 'image/jpeg',
                data: imageBase64.split(',')[1] || imageBase64
              }
            }
          ]
        }
      ],
    });

    const text = response.text || '{}';
    const cleanText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    const analysis = JSON.parse(cleanText);

    const documentType = analysis.documentType || 'unknown';
    const isValid = analysis.isValid || false;
    const confidence = Math.min(100, Math.max(0, analysis.confidence || 0));
    const keywords = Array.isArray(analysis.keywords) ? analysis.keywords.slice(0, 8) : [];

    let message = '';
    let relatedFlow: string | undefined;

    if (documentType === 'unknown') {
      message = language === 'tr'
        ? 'Bu belge tanımlanamadı. Lütfen daha net bir görsel yükleyin.'
        : 'Questo documento non può essere identificato. Si prega di caricare un\'immagine più chiara.';
    } else if (isValid) {
      const typeTranslations: Record<string, { tr: string; it: string }> = {
        isee: { tr: 'ISEE', it: 'ISEE' },
        permesso: { tr: 'Permesso di Soggiorno (Yenileme)', it: 'Permesso di Soggiorno (Rinnovo)' },
        firstPermesso: { tr: 'İlk Permesso di Soggiorno', it: 'Primo Permesso di Soggiorno' },
        codiceFiscale: { tr: 'Codice Fiscale', it: 'Codice Fiscale' },
        spid: { tr: 'SPID', it: 'SPID' },
        tesseraSanitaria: { tr: 'Tessera Sanitaria', it: 'Tessera Sanitaria' },
        cartaIdentita: { tr: 'Carta d\'Identità', it: 'Carta d\'Identità' },
        universita: { tr: 'Üniversite Kaydı', it: 'Iscrizione Università' },
        dsu: { tr: 'DSU/Burs', it: 'DSU/Borsa di Studio' },
        patente: { tr: 'Ehliyet Dönüşümü', it: 'Conversione Patente' },
        anagrafe: { tr: 'İkamet Kaydı', it: 'Residenza/Anagrafe' }
      };

      const typeName = typeTranslations[documentType]?.[language as 'tr' | 'it'] || documentType;
      message = language === 'tr'
        ? `✅ Bu belge ${typeName} için uygun.`
        : `✅ Questo documento è adatto per ${typeName}.`;
      relatedFlow = documentType;
    } else {
      const typeTranslations: Record<string, { tr: string; it: string }> = {
        isee: { tr: 'ISEE', it: 'ISEE' },
        permesso: { tr: 'Permesso di Soggiorno (Yenileme)', it: 'Permesso di Soggiorno (Rinnovo)' },
        firstPermesso: { tr: 'İlk Permesso di Soggiorno', it: 'Primo Permesso di Soggiorno' },
        codiceFiscale: { tr: 'Codice Fiscale', it: 'Codice Fiscale' },
        spid: { tr: 'SPID', it: 'SPID' },
        tesseraSanitaria: { tr: 'Tessera Sanitaria', it: 'Tessera Sanitaria' },
        cartaIdentita: { tr: 'Carta d\'Identità', it: 'Carta d\'Identità' },
        universita: { tr: 'Üniversite Kaydı', it: 'Iscrizione Università' },
        dsu: { tr: 'DSU/Burs', it: 'DSU/Borsa di Studio' },
        patente: { tr: 'Ehliyet Dönüşümü', it: 'Conversione Patente' },
        anagrafe: { tr: 'İkamet Kaydı', it: 'Residenza/Anagrafe' }
      };

      const typeName = typeTranslations[documentType]?.[language as 'tr' | 'it'] || documentType;
      message = language === 'tr'
        ? `⚠️ Bu belge standart ${typeName} işlemi için uygun değil, ancak ${typeName} ile ilgili olabilir. ${analysis.notes || ''}`
        : `⚠️ Questo documento non è adatto per la procedura standard di ${typeName}, ma potrebbe essere correlato a ${typeName}. ${analysis.notes || ''}`;
      relatedFlow = documentType;
    }

    return {
      isValid,
      documentType,
      confidence,
      keywords,
      relatedFlow,
      message
    };

  } catch (error) {
    console.error('Document analysis error:', error);
    return {
      isValid: false,
      documentType: 'unknown',
      confidence: 0,
      keywords: [],
      message: language === 'tr' 
        ? 'Belge analiz edilirken hata oluştu. Lütfen tekrar deneyin.' 
        : 'Errore durante l\'analisi del documento. Riprova.'
    };
  }
}
