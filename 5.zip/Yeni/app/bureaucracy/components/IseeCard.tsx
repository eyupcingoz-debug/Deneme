// app/bureaucracy/components/IseeCard.tsx
"use client";

import * as React from "react";
import CafBooking from "@/app/bureaucracy/components/CafBooking";

type User = {
  universityKey?: string; // "polimi" | "sapienza" | ...
  lang?: "tr" | "en" | "ar";
};

// Örnek kullanıcı – gerçek projende user'ı context'ten, store'dan veya props'tan al
const mockUser: User = {
  universityKey: undefined, // set edilmemişse polimi olacak
  lang: "tr",
};

export default function IseeCard() {
  const user = mockUser;
  const uniKey = user.universityKey || "polimi";
  const lang = user.lang || "tr";

  return (
    <div style={{ border: "1px solid #eee", borderRadius: 12, padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
        <h3 style={{ margin: 0 }}>ISEE</h3>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {/* Hâlihazırdaki “Add reminder” butonunun yanına ekle */}
          <button
            type="button"
            onClick={() => alert("Add reminder (mevcut buton)")}
            style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #ddd", cursor: "pointer" }}
          >
            Add reminder
          </button>

          <CafBooking universityKey={uniKey} lang={lang} />
        </div>
      </div>

      <p style={{ color: "#666", marginTop: 12 }}>
        Üniversitenin onayladığı CAF randevu sitelerine hızlı yönlendirme ve 3 gün sonrası için yerel hatırlatıcı ekler.
      </p>
    </div>
  );
}