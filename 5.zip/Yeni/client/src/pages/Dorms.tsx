import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Building2, Users, Bed, Euro, ExternalLink, Filter } from 'lucide-react';
import { allDorms, cities, type Dorm } from '@/data/dorms';

export default function Dorms() {
  const [selectedCity, setSelectedCity] = useState('All');
  const [selectedGender, setSelectedGender] = useState('All');
  const [selectedRoomCapacity, setSelectedRoomCapacity] = useState('All');
  const [priceRange, setPriceRange] = useState<number[]>([0, 1200]);

  const filteredDorms = useMemo(() => {
    return allDorms.filter((dorm: Dorm) => {
      const cityMatch = selectedCity === 'All' || dorm.city === selectedCity;
      const genderMatch = selectedGender === 'All' || dorm.gender === selectedGender;
      const roomMatch = selectedRoomCapacity === 'All' || dorm.roomCapacity === selectedRoomCapacity;
      const priceMatch = dorm.priceMin <= priceRange[1] && dorm.priceMax >= priceRange[0];

      return cityMatch && genderMatch && roomMatch && priceMatch;
    });
  }, [selectedCity, selectedGender, selectedRoomCapacity, priceRange]);

  const dormStats = useMemo(() => {
    return cities.slice(1).map((city: string) => ({
      city,
      count: allDorms.filter((d: Dorm) => d.city === city).length
    }));
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-cyan-50 dark:from-gray-900 dark:to-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-3">
            <Building2 className="h-10 w-10 text-cyan-600" />
            University Dormitories
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Find official university housing across Italy
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {dormStats.map(({ city, count }) => (
              <span
                key={city}
                className="px-3 py-1 bg-white dark:bg-gray-800 rounded-full text-sm text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700"
              >
                {city}: {count}
              </span>
            ))}
          </div>
        </div>

        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-xl">
              <Filter className="h-5 w-5" />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div>
                <Label htmlFor="city-filter" className="mb-2 block">
                  City
                </Label>
                <Select value={selectedCity} onValueChange={setSelectedCity}>
                  <SelectTrigger id="city-filter">
                    <SelectValue placeholder="Select city" />
                  </SelectTrigger>
                  <SelectContent>
                    {cities.map((city: string) => (
                      <SelectItem key={city} value={city}>
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="gender-filter" className="mb-2 block">
                  Gender
                </Label>
                <Select value={selectedGender} onValueChange={setSelectedGender}>
                  <SelectTrigger id="gender-filter">
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All</SelectItem>
                    <SelectItem value="Mixed">Mixed</SelectItem>
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="room-filter" className="mb-2 block">
                  Room Type
                </Label>
                <Select value={selectedRoomCapacity} onValueChange={setSelectedRoomCapacity}>
                  <SelectTrigger id="room-filter">
                    <SelectValue placeholder="Select room type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All</SelectItem>
                    <SelectItem value="Single">Single</SelectItem>
                    <SelectItem value="Double">Double</SelectItem>
                    <SelectItem value="Triple">Triple</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="price-filter" className="mb-2 block">
                  Price Range: €{priceRange[0]} - €{priceRange[1]}
                </Label>
                <Slider
                  id="price-filter"
                  min={0}
                  max={1200}
                  step={50}
                  value={priceRange}
                  onValueChange={setPriceRange}
                  className="mt-2"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="mb-4 text-gray-600 dark:text-gray-400">
          Showing <strong>{filteredDorms.length}</strong> of <strong>{allDorms.length}</strong> dormitories
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDorms.map((dorm: Dorm) => (
            <Card key={`${dorm.city}-${dorm.name}`} className="shadow-lg hover:shadow-xl transition-shadow">
              {dorm.image && (
                <div className="h-48 overflow-hidden rounded-t-lg">
                  <img
                    src={dorm.image}
                    alt={dorm.name}
                    className="w-full h-full object-cover"
                    loading="lazy"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                </div>
              )}
              <CardHeader>
                <CardTitle className="text-lg">{dorm.name}</CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">{dorm.city}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-cyan-600" />
                    <span className="text-gray-700 dark:text-gray-300">{dorm.university}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-cyan-600" />
                    <span className="text-gray-700 dark:text-gray-300">{dorm.gender}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Bed className="h-4 w-4 text-cyan-600" />
                    <span className="text-gray-700 dark:text-gray-300">{dorm.roomCapacity}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Euro className="h-4 w-4 text-cyan-600" />
                    <span className="text-gray-700 dark:text-gray-300">
                      €{dorm.priceMin} - €{dorm.priceMax}/month
                    </span>
                  </div>
                </div>

                {dorm.features && dorm.features.length > 0 && (
                  <div className="mt-4">
                    <div className="flex flex-wrap gap-1">
                      {dorm.features.slice(0, 4).map((feature: string, idx: number) => (
                        <span
                          key={idx}
                          className="px-2 py-1 bg-cyan-50 dark:bg-cyan-900/30 text-cyan-700 dark:text-cyan-300 rounded text-xs"
                        >
                          {feature}
                        </span>
                      ))}
                      {dorm.features.length > 4 && (
                        <span className="px-2 py-1 text-gray-500 text-xs">
                          +{dorm.features.length - 4} more
                        </span>
                      )}
                    </div>
                  </div>
                )}

                <Button
                  className="w-full mt-4 bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-700 hover:to-teal-700"
                  onClick={() => window.open(dorm.applicationLink, '_blank')}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Apply Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredDorms.length === 0 && (
          <Card className="p-12 text-center">
            <p className="text-gray-600 dark:text-gray-400 text-lg">
              No dormitories match your filters. Try adjusting your search criteria.
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
