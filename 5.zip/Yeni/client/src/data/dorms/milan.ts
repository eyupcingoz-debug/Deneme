import { Dorm } from './types';

export const milanDorms: Dorm[] = [
  {
    city: "Milan",
    name: "Camplus Turro",
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 600,
    priceMax: 950,
    applicationLink: "https://www.camplus.it/en/residences/milan-turro/",
    image: "https://www.camplus.it/wp-content/uploads/2019/09/camplus-turro-milano-esterni.jpg",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Gym", "Cafeteria"]
  },
  {
    city: "Milan",
    name: "Residenza Universitaria Arcobaleno",
    university: "Università degli Studi di Milano",
    gender: "Female",
    roomCapacity: "Single",
    priceMin: 450,
    priceMax: 650,
    applicationLink: "https://www.collegio-arcobaleno.it/",
    image: "https://www.collegio-arcobaleno.it/images/struttura/esterni.jpg",
    features: ["Wi-Fi", "Study rooms", "Common kitchen", "Garden"]
  },
  {
    city: "Milan",
    name: "Residenza Universitaria Majorana",
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomCapacity: "Double",
    priceMin: 380,
    priceMax: 580,
    applicationLink: "https://www.ersuimilano.it/",
    image: "https://www.ersuimilano.it/images/residenze/majorana.jpg",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Canteen"]
  },
  {
    city: "Milan",
    name: "Camplus Città Studi",
    university: "Politecnico di Milano",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 650,
    priceMax: 900,
    applicationLink: "https://www.camplus.it/en/residences/milan-citta-studi/",
    image: "https://www.camplus.it/wp-content/uploads/2019/09/camplus-citta-studi.jpg",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Bike parking"]
  },
  {
    city: "Milan",
    name: "Collegio di Milano",
    university: "Multiple universities",
    gender: "Male",
    roomCapacity: "Single",
    priceMin: 500,
    priceMax: 750,
    applicationLink: "https://www.collegiodimilano.it/",
    image: "https://www.collegiodimilano.it/images/struttura.jpg",
    features: ["Wi-Fi", "Library", "Chapel", "Common rooms"]
  },
  {
    city: "Milan",
    name: "Residenza Bocconi",
    university: "Università Bocconi",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 700,
    priceMax: 1100,
    applicationLink: "https://www.unibocconi.eu/housing",
    image: "https://www.unibocconi.eu/sites/default/files/residenza.jpg",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "24/7 security"]
  }
];
