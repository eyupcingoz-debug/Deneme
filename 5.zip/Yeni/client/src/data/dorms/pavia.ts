import { Dorm } from './types';

export const paviaDorms: Dorm[] = [
  {
    city: "Pavia",
    name: "Collegio Ghislieri",
    university: "Università di Pavia",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 200,
    priceMax: 400,
    applicationLink: "https://www.ghislieri.it/",
    image: "https://www.ghislieri.it/images/collegio-esterno.jpg",
    features: ["Wi-Fi", "Library", "Study rooms", "Canteen", "Cultural activities"]
  },
  {
    city: "Pavia",
    name: "Collegio Borromeo",
    university: "Università di Pavia",
    gender: "Male",
    roomCapacity: "Single",
    priceMin: 180,
    priceMax: 380,
    applicationLink: "https://www.collegioborromeo.it/",
    image: "https://www.collegioborromeo.it/images/collegio.jpg",
    features: ["Wi-Fi", "Library", "Chapel", "Study rooms", "Historic building"]
  },
  {
    city: "Pavia",
    name: "Collegio Nuovo",
    university: "Università di Pavia",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 220,
    priceMax: 420,
    applicationLink: "https://www.collegionuovo.it/",
    image: "https://www.collegionuovo.it/images/struttura.jpg",
    features: ["Wi-Fi", "Study rooms", "Canteen", "Sports facilities", "Garden"]
  }
];
