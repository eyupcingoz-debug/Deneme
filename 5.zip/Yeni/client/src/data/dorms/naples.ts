import { Dorm } from './types';

export const naplesDorms: Dorm[] = [
  {
    city: "Naples",
    name: "Residenza Universitaria Parthenope",
    university: "Università Parthenope",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 300,
    priceMax: 500,
    applicationLink: "https://www.adisurc.it/residenze/parthenope",
    image: "https://www.adisurc.it/images/residenze/parthenope.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Sea view"]
  },
  {
    city: "Naples",
    name: "Residenza Federico II",
    university: "Università Federico II",
    gender: "Mixed",
    roomCapacity: "Double",
    priceMin: 250,
    priceMax: 400,
    applicationLink: "https://www.adisurc.it/residenze/federico-ii",
    image: "https://www.adisurc.it/images/residenze/federico-ii.jpg",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Laundry"]
  },
  {
    city: "Naples",
    name: "Residenza Universitaria Mezzocannone",
    university: "Università Federico II",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 350,
    priceMax: 550,
    applicationLink: "https://www.adisurc.it/residenze/mezzocannone",
    image: "https://www.adisurc.it/images/residenze/mezzocannone.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Central location"]
  },
  {
    city: "Naples",
    name: "Casa dello Studente Arco Mirelli",
    university: "Multiple universities",
    gender: "Female",
    roomCapacity: "Single",
    priceMin: 280,
    priceMax: 450,
    applicationLink: "https://www.casadellostudentenapoli.it/",
    image: "https://www.casadellostudentenapoli.it/images/arco-mirelli.jpg",
    features: ["Wi-Fi", "Study rooms", "Chapel", "Common areas"]
  },
  {
    city: "Naples",
    name: "Residenza San Marcellino",
    university: "Università Federico II",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 320,
    priceMax: 520,
    applicationLink: "https://www.adisurc.it/residenze/san-marcellino",
    image: "https://www.adisurc.it/images/residenze/san-marcellino.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Bike parking"]
  }
];
