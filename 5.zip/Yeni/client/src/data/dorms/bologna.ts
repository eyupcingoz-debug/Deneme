import { Dorm } from './types';

export const bolognaDorms: Dorm[] = [
  {
    city: "Bologna",
    name: "Residenza Universitaria Zanolini",
    university: "Università di Bologna",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 350,
    priceMax: 550,
    applicationLink: "https://www.er-go.it/residenze/zanolini",
    image: "https://www.er-go.it/images/residenze/zanolini.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Bike parking"]
  },
  {
    city: "Bologna",
    name: "Residenza Universitaria San Donato",
    university: "Università di Bologna",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 380,
    priceMax: 580,
    applicationLink: "https://www.er-go.it/residenze/san-donato",
    image: "https://www.er-go.it/images/residenze/san-donato.jpg",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Laundry", "Garden"]
  },
  {
    city: "Bologna",
    name: "Collegio Internazionale",
    university: "Università di Bologna",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 450,
    priceMax: 700,
    applicationLink: "https://www.collegiosuperiorebologna.it/",
    image: "https://www.collegiosuperiorebologna.it/images/collegio.jpg",
    features: ["Wi-Fi", "Library", "Conference rooms", "Tutoring"]
  },
  {
    city: "Bologna",
    name: "Residenza Irnerio",
    university: "Università di Bologna",
    gender: "Mixed",
    roomCapacity: "Double",
    priceMin: 280,
    priceMax: 450,
    applicationLink: "https://www.er-go.it/residenze/irnerio",
    image: "https://www.er-go.it/images/residenze/irnerio.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common kitchen"]
  },
  {
    city: "Bologna",
    name: "Residenza Lame",
    university: "Università di Bologna",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 400,
    priceMax: 600,
    applicationLink: "https://www.er-go.it/residenze/lame",
    image: "https://www.er-go.it/images/residenze/lame.jpg",
    features: ["Wi-Fi", "Laundry", "Study rooms", "Bike parking", "Garden"]
  }
];
