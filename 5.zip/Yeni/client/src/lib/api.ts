// API client utilities
const API_BASE = '/api';

export class APIError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'APIError';
  }
}

async function request<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    credentials: 'include', // Important for session cookies
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new APIError(response.status, error.error || error.message || 'Request failed');
  }

  return response.json();
}

// Auth API
export const authAPI = {
  register: (data: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    city: string;
    nationality?: string;
    password: string;
    gdprConsent: boolean;
    language?: string;
  }) => request('/auth/register', { method: 'POST', body: JSON.stringify(data) }),

  login: (email: string, password: string) =>
    request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),

  logout: () => request('/auth/logout', { method: 'POST' }),

  getMe: () => request('/auth/me'),

  verifyEmail: (token: string) =>
    request('/auth/verify-email', { method: 'POST', body: JSON.stringify({ token }) }),

  resendVerification: (email: string, language?: string) =>
    request('/auth/resend-verification', {
      method: 'POST',
      body: JSON.stringify({ email, language }),
    }),

  forgotPassword: (email: string, language?: string) =>
    request('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email, language }),
    }),

  resetPassword: (token: string, newPassword: string) =>
    request('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ token, newPassword }),
    }),
};

// Roommate Listings API
export const roommateAPI = {
  create: (data: any) =>
    request('/roommate-listings', { method: 'POST', body: JSON.stringify(data) }),

  list: (filters?: { city?: string; nationality?: string; budgetMax?: number }) => {
    const params = new URLSearchParams();
    if (filters?.city) params.append('city', filters.city);
    if (filters?.nationality) params.append('nationality', filters.nationality);
    if (filters?.budgetMax) params.append('budgetMax', filters.budgetMax.toString());
    return request(`/roommate-listings?${params.toString()}`);
  },

  myListings: () => request('/roommate-listings/my-listings'),

  delete: (id: string) =>
    request(`/roommate-listings/${id}`, { method: 'DELETE' }),
};

// Room Listings API
export const roomAPI = {
  create: (data: any) =>
    request('/room-listings', { method: 'POST', body: JSON.stringify(data) }),

  list: (filters?: {
    city?: string;
    roomType?: string;
    maxRent?: number;
    nationality?: string;
  }) => {
    const params = new URLSearchParams();
    if (filters?.city) params.append('city', filters.city);
    if (filters?.roomType) params.append('roomType', filters.roomType);
    if (filters?.maxRent) params.append('maxRent', filters.maxRent.toString());
    if (filters?.nationality) params.append('nationality', filters.nationality);
    return request(`/room-listings?${params.toString()}`);
  },
};

// Dormitories API
export const dormitoriesAPI = {
  create: (data: any) =>
    request('/dormitories', { method: 'POST', body: JSON.stringify(data) }),

  list: (city?: string) => {
    const params = city ? `?city=${city}` : '';
    return request(`/dormitories${params}`);
  },
};
