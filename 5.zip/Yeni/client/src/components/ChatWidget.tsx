import { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, Loader2, ArrowDown, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useLocation } from 'wouter';

interface ActionButton {
  label: string;
  path: string;
  icon?: string;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
  actions?: ActionButton[];
}

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const { language } = useLanguage();
  const t = useTranslation(language);
  const [, setLocation] = useLocation();


  // Auto-scroll to bottom when messages change
  const scrollToBottom = (smooth = true) => {
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
  };

  // Check if user is near bottom
  const handleScroll = () => {
    if (messagesContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = messagesContainerRef.current;
      const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
      setShowScrollButton(!isNearBottom && messages.length > 0);
    }
  };

  // Auto-scroll when new messages arrive
  useEffect(() => {
    if (messages.length > 0) {
      const container = messagesContainerRef.current;
      if (container) {
        const { scrollTop, scrollHeight, clientHeight } = container;
        const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
        
        // Only auto-scroll if user is already near bottom
        if (isNearBottom) {
          scrollToBottom();
        }
      } else {
        // First message, always scroll
        scrollToBottom(false);
      }
    }
  }, [messages, isLoading]);

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage, language }),
      });

      const data = await response.json();
      
      if (data.response) {
        setMessages(prev => [...prev, { 
          role: 'assistant', 
          content: data.response,
          actions: data.actions 
        }]);
      } else {
        throw new Error('No response');
      }
    } catch (error) {
      console.error('Chat error:', error);
      const errorMsg = language === 'it' ? 'Errore. Riprova.' :
                       language === 'tr' ? 'Hata oluştu. Tekrar deneyin.' :
                       language === 'ar' ? 'حدث خطأ. حاول مرة أخرى.' :
                       'Error. Please try again.';
      setMessages(prev => [...prev, { role: 'assistant', content: errorMsg }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const placeholderText = language === 'it' ? 'Fai una domanda...' :
                          language === 'tr' ? 'Bir soru sorun...' :
                          language === 'ar' ? 'اطرح سؤالاً...' :
                          'Ask a question...';

  const welcomeText = language === 'it' ? 'Ciao! Chiedimi qualsiasi cosa sulla burocrazia italiana.' :
                      language === 'tr' ? 'Merhaba! İtalyan bürokrasisi hakkında bana soru sorabilirsiniz.' :
                      language === 'ar' ? 'مرحبا! اسألني أي شيء عن البيروقراطية الإيطالية.' :
                      'Hi! Ask me anything about Italian bureaucracy.';

  return (
    <>
      {/* Chat Button - Robot Style */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-4 right-4 md:bottom-6 md:right-6 w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-gradient-to-br from-cyan-400 to-primary shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 active:scale-95 z-[9999] flex items-center justify-center"
        >
          <Bot className="h-7 w-7 md:h-8 md:w-8 text-white" />
        </button>
      )}

      {/* Chat Window - Robot Design */}
      {isOpen && (
        <div className="fixed bottom-0 right-0 md:bottom-6 md:right-6 w-full h-[100dvh] md:h-[500px] md:w-[384px] md:max-w-[calc(100vw-3rem)] bg-white md:rounded-2xl shadow-2xl flex flex-col z-[9999] overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-cyan-400 to-primary border-b border-white/10">
            <div className="flex items-center gap-2 text-white font-bold text-lg">
              <Bot className="w-6 h-6" />
              DocuBot
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-2 rounded hover:bg-white/20 transition-colors duration-200 text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages Area */}
          <div 
            ref={messagesContainerRef}
            onScroll={handleScroll}
            className="flex-1 overflow-y-auto p-4 bg-gradient-to-b from-slate-50 to-white relative"
          >
            {messages.length === 0 && (
              <div style={{ textAlign: 'center', padding: '32px 0', color: '#64748b' }}>
                <div style={{ position: 'relative', display: 'inline-block' }}>
                  <Bot style={{ width: '64px', height: '64px', marginBottom: '12px', color: '#06b6d4' }} />
                  <div style={{
                    position: 'absolute',
                    top: '-4px',
                    right: '-4px',
                    width: '12px',
                    height: '12px',
                    background: '#10b981',
                    borderRadius: '50%',
                    animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite'
                  }}></div>
                </div>
                <p style={{ fontSize: '14px', fontWeight: '500', color: '#0f172a' }}>{welcomeText}</p>
              </div>
            )}

            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex mb-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom duration-300`}
                style={{ animationDelay: `${idx * 50}ms` }}
              >
                <div className="flex flex-col gap-2" style={{ maxWidth: '80%' }}>
                  <div
                    style={{
                      borderRadius: '16px',
                      padding: '12px 16px',
                      background: msg.role === 'user' 
                        ? 'linear-gradient(to bottom right, #06b6d4, #2563eb)'
                        : '#f1f5f9',
                      color: msg.role === 'user' ? 'white' : '#0f172a',
                      boxShadow: msg.role === 'user' 
                        ? '0 4px 6px -1px rgba(6, 182, 212, 0.3)'
                        : '0 1px 3px 0 rgba(0, 0, 0, 0.1)',
                      transition: 'transform 0.2s'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.02)'}
                    onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
                  >
                    <p style={{ fontSize: '14px', lineHeight: '1.5', whiteSpace: 'pre-wrap' }}>{msg.content}</p>
                  </div>
                  
                  {/* Action buttons */}
                  {msg.role === 'assistant' && msg.actions && msg.actions.length > 0 && (
                    <div className="flex flex-col gap-2">
                      {msg.actions.map((action, actionIdx) => (
                        <button
                          key={actionIdx}
                          onClick={() => {
                            setLocation(action.path);
                            setIsOpen(false);
                          }}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            padding: '10px 16px',
                            borderRadius: '12px',
                            background: 'linear-gradient(to right, #06b6d4, #2563eb)',
                            color: 'white',
                            border: 'none',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: '500',
                            boxShadow: '0 2px 8px rgba(6, 182, 212, 0.3)',
                            transition: 'all 0.2s'
                          }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.transform = 'scale(1.05)';
                            e.currentTarget.style.boxShadow = '0 4px 12px rgba(6, 182, 212, 0.4)';
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.transform = 'scale(1)';
                            e.currentTarget.style.boxShadow = '0 2px 8px rgba(6, 182, 212, 0.3)';
                          }}
                        >
                          <ExternalLink style={{ width: '16px', height: '16px' }} />
                          {action.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start mb-4">
                <div className="bg-muted rounded-lg px-4 py-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              </div>
            )}
            
            {/* Scroll anchor */}
            <div ref={messagesEndRef} />

            {/* Scroll to bottom button */}
            {showScrollButton && (
              <button
                onClick={() => scrollToBottom()}
                style={{
                  position: 'absolute',
                  bottom: '16px',
                  right: '16px',
                  width: '40px',
                  height: '40px',
                  borderRadius: '50%',
                  background: 'linear-gradient(to bottom right, #06b6d4, #2563eb)',
                  border: 'none',
                  color: 'white',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                  transition: 'transform 0.2s, opacity 0.2s',
                  opacity: 0.9,
                  zIndex: 10
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'scale(1.1)';
                  e.currentTarget.style.opacity = '1';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'scale(1)';
                  e.currentTarget.style.opacity = '0.9';
                }}
              >
                <ArrowDown style={{ width: '20px', height: '20px' }} />
              </button>
            )}
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-slate-200 bg-white">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={placeholderText}
                disabled={isLoading}
                className="flex-1 px-3 py-2 border-2 border-slate-200 rounded-lg text-sm outline-none focus:border-cyan-400 transition-colors duration-200"
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim() || isLoading}
                className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-primary rounded-lg text-white flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg transition-all duration-200 active:scale-95"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
