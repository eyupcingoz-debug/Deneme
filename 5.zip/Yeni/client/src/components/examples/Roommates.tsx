import { LanguageProvider } from '@/contexts/LanguageContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { Toaster } from '@/components/ui/toaster';
import Roommates from '../../pages/Roommates';

export default function RoommatesExample() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <Roommates />
        <Toaster />
      </LanguageProvider>
    </ThemeProvider>
  );
}
