import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, ExternalLink, Copy, ShieldAlert } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';

interface MapModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  locationUrl: string;
  title: string;
}

export default function MapModal({ open, onOpenChange, locationUrl, title }: MapModalProps) {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();
  const [showIframe, setShowIframe] = useState(true);

  // Check if URL is a Google Maps link
  const isGoogleMapsUrl = (url: string): boolean => {
    return url.includes('google.com/maps') || url.includes('goo.gl/maps');
  };

  // Convert Google Maps URL to embed format
  const getEmbedUrl = (url: string): string => {
    if (!isGoogleMapsUrl(url)) {
      return '';
    }

    try {
      // Extract coordinates or place information from the URL
      const urlObj = new URL(url);
      
      // Try to get the query from the URL
      let query = '';
      
      // Check for /maps/place/ format
      const placeMatch = url.match(/\/maps\/place\/([^\/]+)/);
      if (placeMatch) {
        query = decodeURIComponent(placeMatch[1]);
      }
      
      // Check for @coordinates format
      const coordMatch = url.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
      if (coordMatch) {
        query = `${coordMatch[1]},${coordMatch[2]}`;
      }
      
      // Check for query parameter
      if (!query && urlObj.searchParams.get('q')) {
        query = urlObj.searchParams.get('q') || '';
      }
      
      if (query) {
        return `https://www.google.com/maps?q=${encodeURIComponent(query)}&output=embed`;
      }
      
      return '';
    } catch {
      return '';
    }
  };

  const embedUrl = getEmbedUrl(locationUrl);
  const canEmbed = isGoogleMapsUrl(locationUrl) && embedUrl;

  // 3-step link opening mechanism
  const openInNewTab = () => {
    // Step 1: Try window.open
    const newWindow = window.open(locationUrl, '_blank', 'noopener,noreferrer');
    
    if (newWindow) {
      // Success - window opened
      toast({
        title: t('linkOpened'),
        description: t('viewDetails'),
      });
      return;
    }

    // Step 2: Try anchor.click()
    const anchor = document.createElement('a');
    anchor.href = locationUrl;
    anchor.target = '_blank';
    anchor.rel = 'noopener noreferrer';
    document.body.appendChild(anchor);
    
    try {
      anchor.click();
      document.body.removeChild(anchor);
      
      toast({
        title: t('linkOpened'),
      });
      return;
    } catch {
      document.body.removeChild(anchor);
    }

    // Step 3: Copy to clipboard as fallback
    copyToClipboard();
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(locationUrl)
      .then(() => {
        toast({
          title: t('linkCopied'),
          description: t('mapBlocked'),
        });
      })
      .catch(() => {
        toast({
          title: t('clipboardFailed'),
          variant: 'destructive',
        });
      });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="dialog-map">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            {title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Map Embed or Fallback Buttons */}
          {canEmbed && showIframe ? (
            <div className="w-full h-96 rounded-lg overflow-hidden border">
              <iframe
                src={embedUrl}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title={t('location')}
                onError={() => {
                  setShowIframe(false);
                  copyToClipboard();
                }}
              />
            </div>
          ) : (
            <Alert data-testid="alert-map-fallback">
              <MapPin className="h-4 w-4" />
              <AlertDescription>
                {canEmbed 
                  ? t('mapBlocked')
                  : t('showLocation')}
              </AlertDescription>
            </Alert>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2 flex-wrap">
            <Button
              variant="default"
              onClick={openInNewTab}
              className="flex-1"
              data-testid="button-open-new-tab"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              {t('openInNewTab')}
            </Button>
            <Button
              variant="outline"
              onClick={copyToClipboard}
              className="flex-1"
              data-testid="button-copy-link"
            >
              <Copy className="h-4 w-4 mr-2" />
              {t('copyLink')}
            </Button>
          </div>

          {/* Security Warning */}
          <Alert variant="default" className="bg-muted/50" data-testid="alert-security">
            <ShieldAlert className="h-4 w-4" />
            <AlertDescription className="text-sm">
              {t('securityNote')}
            </AlertDescription>
          </Alert>
        </div>
      </DialogContent>
    </Dialog>
  );
}
