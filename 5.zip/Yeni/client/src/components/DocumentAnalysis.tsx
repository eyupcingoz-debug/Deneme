import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Upload, FileCheck, AlertCircle, Loader2, Eye, X } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

interface AnalysisResult {
  isValid: boolean;
  documentType: string;
  confidence: number;
  keywords: string[];
  relatedFlow?: string;
  message: string;
}

export default function DocumentAnalysis() {
  const { language, isRTL } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [analyzing, setAnalyzing] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    if (!validTypes.includes(file.type)) {
      toast({
        title: t('docAnalysisError'),
        description: t('docAnalysisInvalidFormat'),
        variant: 'destructive'
      });
      return;
    }

    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      toast({
        title: t('docAnalysisError'),
        description: t('docAnalysisFileTooLarge'),
        variant: 'destructive'
      });
      return;
    }

    setSelectedFile(file);
    setResult(null);

    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setPreviewUrl(null);
    }
  };

  const analyzeDocument = async () => {
    if (!selectedFile) return;

    setAnalyzing(true);
    setResult(null);

    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const base64 = reader.result as string;

          const response = await fetch('/api/analyze-document', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              imageBase64: base64,
              language: language === 'tr' ? 'tr' : 'it'
            }),
          });

          if (!response.ok) {
            throw new Error('Analysis failed');
          }

          const analysisResult: AnalysisResult = await response.json();
          setResult(analysisResult);

          clearFile();

          toast({
            title: t('docAnalysisComplete'),
            description: analysisResult.message,
          });
        } catch (error) {
          console.error('Analysis error:', error);
          toast({
            title: t('docAnalysisError'),
            description: t('docAnalysisFailed'),
            variant: 'destructive'
          });
        } finally {
          setAnalyzing(false);
        }
      };

      reader.readAsDataURL(selectedFile);
    } catch (error) {
      setAnalyzing(false);
      toast({
        title: t('docAnalysisError'),
        description: t('docAnalysisFailed'),
        variant: 'destructive'
      });
    }
  };

  const clearFile = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const clearResult = () => {
    setResult(null);
  };

  const openRelatedFlow = () => {
    if (result?.relatedFlow) {
      setLocation('/bureaucracy');
      toast({
        title: t('docAnalysisRedirect'),
        description: t('docAnalysisRedirectDesc'),
      });
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'bg-green-500';
    if (confidence >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileCheck className="h-5 w-5 text-cyan-500" />
            {t('docAnalysisTitle')}
          </CardTitle>
          <CardDescription>{t('docAnalysisDesc')}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center hover:border-muted-foreground/50 transition-colors">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/jpg,image/png,application/pdf"
              onChange={handleFileSelect}
              className="hidden"
              id="document-upload"
            />
            <label
              htmlFor="document-upload"
              className="cursor-pointer flex flex-col items-center gap-3"
            >
              <Upload className="h-12 w-12 text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">{t('docAnalysisUpload')}</p>
                <p className="text-sm text-muted-foreground mt-1">
                  {t('docAnalysisFormats')}
                </p>
              </div>
            </label>
          </div>

          {selectedFile && (
            <Alert>
              <Eye className="h-4 w-4" />
              <AlertDescription className="flex items-center justify-between">
                <span className="flex-1">{selectedFile.name}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFile}
                  disabled={analyzing}
                >
                  <X className="h-4 w-4" />
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {previewUrl && (
            <div className="rounded-lg overflow-hidden border">
              <img
                src={previewUrl}
                alt="Document preview"
                className="w-full h-auto max-h-64 object-contain bg-muted"
              />
            </div>
          )}

          {selectedFile && (
            <Button
              onClick={analyzeDocument}
              disabled={analyzing}
              className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
            >
              {analyzing ? (
                <>
                  <Loader2 className={`h-4 w-4 animate-spin ${isRTL ? 'ml-2' : 'mr-2'}`} />
                  {t('docAnalysisAnalyzing')}
                </>
              ) : (
                <>
                  <FileCheck className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                  {t('docAnalysisAnalyze')}
                </>
              )}
            </Button>
          )}
        </CardContent>
      </Card>

      {result && (
        <Card className="border-2 border-cyan-500/50 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                {result.isValid ? (
                  <FileCheck className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-yellow-500" />
                )}
                {t('docAnalysisResults')}
              </span>
              <Button variant="ghost" size="sm" onClick={clearResult}>
                <X className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant={result.isValid ? 'default' : 'destructive'}>
              <AlertDescription className="text-base">
                {result.message}
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">
                  {t('docAnalysisConfidence')}
                </p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold">{result.confidence}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                    <div
                      className={`h-full transition-all ${getConfidenceColor(result.confidence)}`}
                      style={{ width: `${result.confidence}%` }}
                    />
                  </div>
                </div>
              </div>

              {result.keywords.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">
                    {t('docAnalysisKeywords')}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {result.keywords.map((keyword, index) => (
                      <Badge key={index} variant="secondary">
                        {keyword}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {result.relatedFlow && (
              <Button
                onClick={openRelatedFlow}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
              >
                {t('docAnalysisOpenForm')}
              </Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
