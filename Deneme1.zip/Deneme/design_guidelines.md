# DocuBuddy+ Design Guidelines

## Design Approach
**Selected System:** Material Design 3 adapted for modern web applications
**Justification:** Information-dense utility app requiring clear hierarchy, accessible forms, and consistent component patterns. Material Design provides excellent guidelines for task management, data display, and multi-language support including RTL layouts.

## Core Design Principles
1. **Clarity First:** Clear visual hierarchy for bureaucratic tasks and status indicators
2. **Trust Through Design:** Professional, trustworthy aesthetic for sensitive student documentation
3. **Efficient Navigation:** Quick access to three core functions (Bureaucracy, Roommates, Calendar)
4. **Multi-language Ready:** Clean typography that works across IT/EN/TR/AR with RTL support

## Color Palette

**Light Mode:**
- Primary: 220 70% 50% (Trustworthy blue for institutional feel)
- Primary Variant: 220 80% 40% (Darker blue for emphasis)
- Success: 142 76% 36% (Green for approved/OK status)
- Error: 0 84% 60% (Red for "Needs Fix" alerts)
- Surface: 0 0% 98% (Clean white background)
- Surface Variant: 220 20% 95% (Subtle card backgrounds)
- Text Primary: 220 20% 10%
- Text Secondary: 220 15% 40%

**Dark Mode:**
- Primary: 220 70% 60%
- Primary Variant: 220 80% 50%
- Success: 142 70% 45%
- Error: 0 72% 65%
- Surface: 220 20% 10%
- Surface Variant: 220 18% 15%
- Text Primary: 220 10% 95%
- Text Secondary: 220 10% 70%

## Typography
- **Primary Font:** Inter (via Google Fonts) - excellent multi-language support including Arabic
- **Headings:** 
  - H1: text-4xl font-bold (Landing page title)
  - H2: text-3xl font-semibold (Page titles)
  - H3: text-xl font-semibold (Section headers)
  - H4: text-lg font-medium (Card titles, flow names)
- **Body:** text-base leading-relaxed
- **Small/Meta:** text-sm text-secondary
- **RTL Support:** Add `dir="rtl"` class with adjusted padding/margin utilities for Arabic

## Layout System
**Spacing Units:** Use Tailwind spacing scale: 2, 4, 6, 8, 12, 16, 20, 24
- Page padding: px-4 md:px-8 lg:px-12
- Section spacing: py-12 md:py-16
- Card padding: p-6
- Component gaps: gap-4 (standard), gap-6 (sections), gap-8 (major sections)
- Max content width: max-w-6xl mx-auto

## Component Library

### Navigation Bar
- Fixed top navigation with backdrop blur (backdrop-blur-md bg-surface/90)
- Logo/brand on left: "DocuBuddy+" with subtle icon
- Main navigation links centered: Bureaucracy | Roommates | Calendar
- Language switcher on right: Dropdown with flags (IT/EN/TR/AR)
- Height: h-16, sticky positioning

### Landing Page Hero
- Centered layout with gradient background (subtle blue gradient)
- Large heading with DocuBuddy+ branding
- Tagline: "Bureaucracy & Roommates Assistant for Students in Italy"
- Three large action buttons in grid (grid-cols-1 md:grid-cols-3 gap-6):
  - Each button: Rounded cards with icon, title, brief description
  - Hover state: Subtle lift (transform translate-y-1)

### Bureaucracy Flow Cards
- Three main flow cards in grid layout
- Each card contains:
  - Flow title with icon (document/file icon)
  - Progress indicator (e.g., "3/6 completed")
  - Checklist items with checkboxes (interactive state changes)
  - Upload button (primary action)
  - Status badge: Green pill "OK" or Red pill "Needs Fix"
  - "Add Reminder" secondary button
- Card style: Rounded-lg border surface-variant shadow-sm

### Roommate Profile Form
- Single column form with clear section breaks
- Input groups with labels above inputs
- Range sliders for cleanliness/noise (1-5 scale with visual indicators)
- Toggle switches for binary options (pets, smoker)
- Budget inputs: Two number inputs (min/max) with currency symbol
- Action buttons at bottom: Save (primary), Preview (secondary), Find Matches (accent)

### Match Cards
- Grid layout: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Each card shows:
  - Match percentage in large bold text (top right corner)
  - Profile avatar placeholder (colored circle with initials)
  - Key attributes with icons (city, budget, lifestyle tags)
  - Compatibility indicators with color-coded badges
  - "Contact" button (disabled in prototype, styled as secondary)

### Calendar/Reminder List
- Clean list view with alternating subtle backgrounds
- Each reminder item:
  - Left border colored by urgency (red for overdue, yellow for upcoming, green for future)
  - Title in bold
  - Due date with calendar icon
  - Category tag (e.g., "ISEE", "Permesso")
  - Delete/edit icon buttons (ghost style)

### Settings Page
- Card-based layout for language selection
- Large clickable language cards with flag icons
- Active language highlighted with primary border
- RTL preview toggle for testing

## Status Indicators
- **Upload Status:**
  - OK: Green circle with check icon, "Document Approved" text
  - Needs Fix: Red circle with alert icon, "Requires Update" text
- **Task Progress:** Linear progress bars with percentage
- **Match Score:** Circular percentage badge with color gradient (red <50%, yellow 50-75%, green >75%)

## Animations
**Minimal and Purposeful:**
- Page transitions: Simple fade-in (300ms)
- Card hover: Subtle lift and shadow increase
- Button interactions: Scale on press (scale-95)
- Status changes: Color transition (300ms ease)
- No complex animations or parallax effects

## Images
**Hero Section:** 
- Abstract illustration or photo showing diverse students collaborating
- Style: Modern, warm, inclusive imagery
- Placement: Right side of hero on desktop, above text on mobile
- Treatment: Slight overlay for text readability

**Empty States:**
- Simple line illustrations for empty bureaucracy tasks, no matches found, empty calendar
- Friendly and encouraging tone

## Accessibility
- Maintain WCAG AA contrast ratios in both light and dark modes
- All interactive elements have minimum 44px touch targets
- Focus states clearly visible with 2px primary-colored outline
- Form inputs with clear error states and helpful error messages
- RTL layout properly mirrors all directional elements for Arabic
- Skip navigation link for keyboard users