# DocuBuddy+ - Student Documentation Assistant

## Overview

DocuBuddy+ is a full-stack web application designed to assist international students in Italy. Its primary purpose is to simplify bureaucratic tasks, facilitate roommate matching, and help track critical deadlines. The application features an AI-powered chatbot (DocuBot) for multilingual bureaucratic assistance, a comprehensive bureaucracy manager, a lifestyle-based roommate finder, and a personal calendar/reminder system. It supports Italian, English, Turkish, and Arabic (with RTL support) and aims to provide a modern, user-friendly experience. The project integrates an authentication system with PostgreSQL for user and listing data and is set up for Autoscale deployment.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (October 2025)

### October 28, 2025 - Bureaucracy Guide System Extension (4 New Guides)
- ✅ Added 4 comprehensive new bureaucracy guides with full multilingual support (Turkish, Italian, English):
  - Driver's License Conversion (Ehliyet): Converting Turkish license to Italian patente
  - University Registration (Üniversite Kaydı): Complete immatricolazione process
  - ISEE University (ISEE): Economic status certificate for tuition and scholarships
  - DSU Scholarship (Burs): Regional scholarship and dormitory application process
- ✅ Updated guideFileMapping in BureaucracyFlow.tsx to include new guides
- ✅ Implemented language-aware error messages in GuideModal.tsx
- ✅ Created guide files in all three supported languages:
  - Turkish: ehliyet.txt, universite-kaydi.txt, isee.txt, dsu-burs.txt
  - Italian: ehliyet.txt, universite-kaydi.txt, isee.txt, dsu-burs.txt
  - English: ehliyet.txt, universite-kaydi.txt, isee.txt, dsu-burs.txt
- ✅ All guide translations reviewed and verified by architect
- ✅ Note: Arabic guide files not yet created (Arabic support pending)

### October 28, 2025 - Bureaucracy Guide System Implementation
- ✅ Replaced document upload functionality with comprehensive text guide system
- ✅ Created GuideModal component for displaying procedural guides
- ✅ Organized guide texts in client/public/texts/{language}/ structure for multilingual support
- ✅ Added "How to Apply" (Nasıl Başvurulur/Come Applicare) buttons to bureaucracy flows
- ✅ Implemented 9 comprehensive Turkish guides covering:
  - Codice Fiscale application process
  - First Permesso di Soggiorno (residence permit)
  - Permesso renewal process
  - Health Card (Tessera Sanitaria) registration
  - ID Card (Carta d'Identità) application
  - SPID digital identity setup
  - Hospital appointment booking
  - Family doctor registration
  - Residence registration (Anagrafe)
- ✅ Removed all "Upload Document" sections from bureaucracy flows
- ✅ Kept "Controllo Documenti (IA)" AI document checker unchanged
- ✅ Guide texts stored as separate .txt files to minimize app bundle size
- ✅ Language-aware guide loading with proper error handling
- ✅ All changes architect-reviewed and approved

### October 28, 2025 - GitHub Import & Replit Environment Setup
- ✅ Successfully imported project from GitHub multi-part zip archive
- ✅ Extracted and organized all project files to root directory
- ✅ Installed Node.js 20 runtime environment
- ✅ Installed all npm dependencies (503 packages)
- ✅ Connected to existing PostgreSQL database (heliumdb)
- ✅ Pushed database schema using Drizzle ORM (users, roommate_listings, room_listings, dormitories tables)
- ✅ Configured development workflow for port 5000
- ✅ Verified Vite configuration for Replit proxy support (host: 0.0.0.0, allowedHosts: true)
- ✅ Set up Autoscale deployment configuration with build and start commands
- ✅ Application successfully running and tested

### October 23, 2025 - Mobile Navbar Overflow & Dark Mode Fixes
- ✅ Fixed mobile navbar overflow issues:
  - Reduced button sizes to `sm` for auth, language, and theme controls
  - Made text smaller on mobile (text-xs sm:text-sm)
  - Tighter spacing with gap-1 sm:gap-2
  - Language selector shows icon-only on mobile, text on large screens (hidden lg:inline)
  - Smaller icon sizes (h-8 w-8 on mobile, h-10 w-10 on desktop)
  - Reduced padding (px-2 sm:px-4) to fit within 320-414px viewports
- ✅ Implemented comprehensive dark mode support:
  - Navbar background: dark gradient from gray-900 via gray-800
  - Border colors: dark:border-cyan-800
  - Text colors: dark:text-cyan-400 for buttons, dark:text-gray-200 for general text
  - Hover states: dark:hover:bg-gray-800 for proper feedback
  - Dropdown menus: dark:bg-gray-800 with dark:border-gray-700
  - Applied to both desktop and mobile navigation
  - Improved contrast and readability in dark mode
- ✅ All changes architect-reviewed and approved

## System Architecture

### Frontend Architecture

**Framework Stack:**
- **React 18** with TypeScript
- **Vite** for fast HMR and optimized builds
- **Wouter** for client-side routing
- **Tailwind CSS** for styling, with custom color palettes (cyan/teal gradient theme) and Material Design 3 principles.
- **shadcn/ui** components built on Radix UI primitives.
- **lucide-react** for SVG icons.
- **Inter** font family for multilingual support.

**Key Features:**
- **Bureaucracy Manager:** Guides students through ISEE, Permesso di Soggiorno, and SPID processes with checklists, file upload simulations, and CAF appointment integration.
- **Roommate Finder:** Lifestyle-based matching system with profile creation, compatibility scoring, and listings management.
- **Calendar/Reminders:** Deadline tracking with visual urgency indicators and automatic reminder creation from bureaucracy flows.
- **Internationalization:** Full i18n support for IT, EN, TR, AR, including RTL layout for Arabic.
- **AI Chatbot (DocuBot):** AI-powered assistance for bureaucratic questions using Google's Gemini AI, supporting multiple languages.

### Backend Architecture

**Technology Stack:**
- **Node.js** with Express.js for API endpoints.
- **PostgreSQL** database for persistent storage of user data, roommate listings, room listings, and dormitories.

**Core Functionality:**
- **Authentication System:** User registration (with GDPR), email/password login, email verification, password reset, and protected routes.
- **API Endpoints:** CRUD operations for roommate listings, room listings, and dormitories.
- **Access Restrictions:** Differentiates between anonymous, verified, and unverified users for content creation and access.

### Application Structure

- **Client-side routing:** `/`, `/bureaucracy`, `/roommates`, `/calendar`, `/settings`.
- **Directory structure:** `components/`, `contexts/`, `hooks/`, `lib/`, `pages/`.

### Build and Deployment

- **Development:** Vite dev server on port 5000 with Express backend proxy.
- **Production:** `npm run build` (Vite for client, esbuild for server), `node dist/index.js` for Autoscale deployment.

## External Dependencies

- **UI Component Libraries:** `@radix-ui/`, `shadcn/ui`, `lucide-react`, `cmdk`, `embla-carousel-react`.
- **Form Management:** `react-hook-form`, `@hookform/resolvers`, `zod`.
- **Styling:** `tailwindcss`, `tailwind-merge`, `class-variance-authority`, `autoprefixer`.
- **Database:** `drizzle-orm`, `drizzle-kit`, `@neondatabase/serverless`, `drizzle-zod` (PostgreSQL configured, but email service needs manual setup).
- **Date Handling:** `date-fns`.
- **AI:** Google's Gemini API (requires `GEMINI_API_KEY` for full functionality).
- **Development Tools:** `Vite`, `TypeScript`, `@vitejs/plugin-react`, `tsx`, `esbuild`.
- **Replit Integration:** `@replit/vite-plugin-runtime-error-modal`, `@replit/vite-plugin-cartographer`, `@replit/vite-plugin-dev-banner`.
- **Session Management (Server-Side):** `express-session`, `connect-pg-simple`.