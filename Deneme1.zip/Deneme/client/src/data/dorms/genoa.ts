import { Dorm } from './types';

export const genoaDorms: Dorm[] = [
  {
    city: "Genoa",
    name: "Residenza Universitaria Montaldo",
    university: "Università di Genova",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 280,
    priceMax: 450,
    applicationLink: "https://www.aliseo.liguria.it/residenze/montaldo",
    image: "https://www.aliseo.liguria.it/images/residenze/montaldo.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Canteen"]
  },
  {
    city: "Genoa",
    name: "Residenza Universitaria Carrara",
    university: "Università di Genova",
    gender: "Mixed",
    roomCapacity: "Double",
    priceMin: 220,
    priceMax: 380,
    applicationLink: "https://www.aliseo.liguria.it/residenze/carrara",
    image: "https://www.aliseo.liguria.it/images/residenze/carrara.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common kitchen"]
  },
  {
    city: "Genoa",
    name: "Collegio Universitario Emiliani",
    university: "Multiple universities",
    gender: "Male",
    roomCapacity: "Single",
    priceMin: 350,
    priceMax: 550,
    applicationLink: "https://www.collegioemiliani.it/",
    image: "https://www.collegioemiliani.it/images/collegio.jpg",
    features: ["Wi-Fi", "Chapel", "Library", "Study rooms", "Sports facilities"]
  }
];
