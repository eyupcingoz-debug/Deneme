import { Dorm } from './types';

export const turinDorms: Dorm[] = [
  {
    city: "Turin",
    name: "Camplus Bernini",
    university: "Politecnico di Torino",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 500,
    priceMax: 750,
    applicationLink: "https://www.camplus.it/en/residences/turin-bernini/",
    image: "https://www.camplus.it/wp-content/uploads/2019/09/camplus-bernini.jpg",
    features: ["Wi-Fi", "Gym", "Study rooms", "Laundry", "Bike parking"]
  },
  {
    city: "Turin",
    name: "Residenza Cavalli",
    university: "Università di Torino",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 320,
    priceMax: 500,
    applicationLink: "https://www.edisu.piemonte.it/residenze/cavalli",
    image: "https://www.edisu.piemonte.it/images/residenze/cavalli.jpg",
    features: ["Wi-Fi", "Canteen", "Study rooms", "Laundry"]
  },
  {
    city: "Turin",
    name: "Residenza Camillo Olivetti",
    university: "Politecnico di Torino",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 380,
    priceMax: 580,
    applicationLink: "https://www.edisu.piemonte.it/residenze/olivetti",
    image: "https://www.edisu.piemonte.it/images/residenze/olivetti.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Common areas"]
  },
  {
    city: "Turin",
    name: "Collegio Universitario Renato Einaudi",
    university: "Multiple universities",
    gender: "Mixed",
    roomCapacity: "Single",
    priceMin: 450,
    priceMax: 700,
    applicationLink: "https://www.collegioeinaudi.it/",
    image: "https://www.collegioeinaudi.it/images/collegio.jpg",
    features: ["Wi-Fi", "Library", "Conference rooms", "Gym", "Cultural events"]
  },
  {
    city: "Turin",
    name: "Residenza Lagrange",
    university: "Università di Torino",
    gender: "Mixed",
    roomCapacity: "Double",
    priceMin: 280,
    priceMax: 450,
    applicationLink: "https://www.edisu.piemonte.it/residenze/lagrange",
    image: "https://www.edisu.piemonte.it/images/residenze/lagrange.jpg",
    features: ["Wi-Fi", "Study rooms", "Laundry", "Canteen access"]
  }
];
