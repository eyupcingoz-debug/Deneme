import { Dorm } from './types';
import { milanDorms } from './milan';
import { romeDorms } from './rome';
import { bolognaDorms } from './bologna';
import { turinDorms } from './turin';
import { naplesDorms } from './naples';
import { genoaDorms } from './genoa';
import { paviaDorms } from './pavia';
import { piacenzaDorms } from './piacenza';

export const allDorms = [
  ...milanDorms,
  ...romeDorms,
  ...bolognaDorms,
  ...turinDorms,
  ...naplesDorms,
  ...genoaDorms,
  ...paviaDorms,
  ...piacenzaDorms
];

export const cities = [
  'All',
  'Milan',
  'Rome',
  'Bologna',
  'Turin',
  'Naples',
  'Genoa',
  'Pavia',
  'Piacenza'
];

export type { Dorm };

export {
  milanDorms,
  romeDorms,
  bolognaDorms,
  turinDorms,
  naplesDorms,
  genoaDorms,
  paviaDorms,
  piacenzaDorms
};
