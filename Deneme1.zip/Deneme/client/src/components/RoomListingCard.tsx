import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Euro, Home } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';

export interface RoomListing {
  id: string;
  title: string;
  description: string;
  city: string;
  rentPrice: number;
  locationUrl?: string;
  ownerName: string;
  photos?: string[];
  smoking?: 'allowed' | 'notAllowed';
  pets?: 'allowed' | 'notAllowed';
  furnished?: 'yes' | 'no';
  genderPreference?: 'female' | 'male' | 'none';
  deposit?: number;
  billsIncluded?: boolean;
}

interface RoomListingCardProps {
  listing: RoomListing;
  onViewDetails: (listing: RoomListing) => void;
}

export default function RoomListingCard({ listing, onViewDetails }: RoomListingCardProps) {
  const { language } = useLanguage();
  const t = useTranslation(language);

  return (
    <Card className="group relative overflow-hidden hover:shadow-2xl hover:shadow-cyan-500/20 transition-all duration-500 transform hover:-translate-y-2 border-2 border-transparent hover:border-cyan-200 dark:hover:border-cyan-800 bg-gradient-to-br from-white to-cyan-50/30 dark:from-slate-800 dark:to-cyan-950/20" data-testid={`card-listing-${listing.id}`}>
      {listing.photos && listing.photos.length > 0 ? (
        <div className="relative aspect-video w-full overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent z-10"></div>
          <img 
            src={listing.photos[0]} 
            alt={listing.title} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute bottom-4 left-4 right-4 z-20">
            <h3 className="font-bold text-lg text-white drop-shadow-lg line-clamp-1 mb-1">{listing.title}</h3>
            <p className="text-sm text-white/90 drop-shadow line-clamp-1">{listing.ownerName}</p>
          </div>
        </div>
      ) : (
        <div className="relative aspect-video w-full overflow-hidden bg-gradient-to-br from-cyan-500 via-teal-500 to-blue-500 flex items-center justify-center">
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
          <Home className="h-20 w-20 text-white/30 relative z-10" />
          <div className="absolute bottom-4 left-4 right-4 z-20">
            <h3 className="font-bold text-lg text-white drop-shadow-lg line-clamp-1 mb-1">{listing.title}</h3>
            <p className="text-sm text-white/90 drop-shadow line-clamp-1">{listing.ownerName}</p>
          </div>
        </div>
      )}
      
      <CardContent className="space-y-4 pt-6 pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 text-cyan-600 dark:text-cyan-400" />
            <span className="font-medium text-foreground">{listing.city}</span>
          </div>
          {listing.locationUrl && (
            <Badge variant="outline" className="text-xs border-cyan-300 text-cyan-700 dark:text-cyan-300">
              <MapPin className="h-3 w-3 mr-1" />
              {t('location')}
            </Badge>
          )}
        </div>

        <div className="flex items-baseline gap-2">
          <div className="flex items-center gap-1">
            <Euro className="h-5 w-5 text-cyan-600 dark:text-cyan-400" />
            <span className="text-3xl font-bold bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent">
              {listing.rentPrice}
            </span>
          </div>
          <span className="text-sm text-muted-foreground">/month</span>
        </div>

        {listing.deposit && listing.deposit > 0 && (
          <div className="text-sm text-muted-foreground">
            + €{listing.deposit} {t('deposit')}
          </div>
        )}

        <p className="text-sm text-muted-foreground line-clamp-2 min-h-[2.5rem]">
          {listing.description}
        </p>
        
        <div className="flex flex-wrap gap-2 pt-2">
          {listing.smoking === 'allowed' && (
            <Badge variant="outline" className="text-xs border-orange-300 text-orange-700 dark:text-orange-300 bg-orange-50 dark:bg-orange-950/30">
              {t('smokingAllowed')}
            </Badge>
          )}
          {listing.smoking === 'notAllowed' && (
            <Badge variant="outline" className="text-xs border-green-300 text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950/30">
              {t('noSmoking')}
            </Badge>
          )}
          {listing.pets === 'allowed' && (
            <Badge variant="outline" className="text-xs border-blue-300 text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/30">
              {t('petFriendly')}
            </Badge>
          )}
          {listing.pets === 'notAllowed' && (
            <Badge variant="outline" className="text-xs border-gray-300 text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-950/30">
              {t('noPets')}
            </Badge>
          )}
          {listing.furnished === 'yes' && (
            <Badge variant="outline" className="text-xs border-purple-300 text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/30">
              {t('furnished')}
            </Badge>
          )}
          {listing.furnished === 'no' && (
            <Badge variant="outline" className="text-xs border-gray-300 text-gray-700 dark:text-gray-300">
              {t('unfurnished')}
            </Badge>
          )}
          {listing.billsIncluded && (
            <Badge variant="outline" className="text-xs border-teal-300 text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/30">
              {t('billsIncluded')}
            </Badge>
          )}
          {listing.genderPreference === 'female' && (
            <Badge variant="outline" className="text-xs border-pink-300 text-pink-700 dark:text-pink-300 bg-pink-50 dark:bg-pink-950/30">
              {t('femaleOnly')}
            </Badge>
          )}
          {listing.genderPreference === 'male' && (
            <Badge variant="outline" className="text-xs border-blue-300 text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/30">
              {t('maleOnly')}
            </Badge>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="pt-0">
        <Button 
          variant="outline" 
          className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-600 hover:to-teal-600 text-white border-0 font-semibold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105" 
          onClick={() => onViewDetails(listing)}
          data-testid={`button-view-details-${listing.id}`}
        >
          {t('viewDetails')}
        </Button>
      </CardFooter>
    </Card>
  );
}
