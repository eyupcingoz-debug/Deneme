import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Bell } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { useToast } from '@/hooks/use-toast';
import CafBooking from './CafBooking';
import { PermessoBooking } from './PermessoBooking';
import { CodiceFiscaleBooking } from './CodiceFiscaleBooking';
import { GuideModal } from './GuideModal';

interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

interface FlowData {
  title: string;
  items: ChecklistItem[];
}

const guideFileMapping: Record<string, string | null> = {
  codiceFiscale: 'codice-fiscale',
  firstPermesso: 'ilk-permesso',
  permesso: 'permesso-yenileme',
  tesseraSanitaria: 'saglik-karti',
  cartaIdentita: 'kimlik-karti',
  spid: 'spid',
  prenotazioneVisita: 'hastane-randevusu',
  medicoBase: 'aile-hekimi',
  anagrafe: 'ikamet-bildirimi',
  isee: 'isee',
  patente: 'ehliyet',
  universita: 'universite-kaydi',
  dsu: 'dsu-burs',
  onlineCaf: null,
}

interface BureaucracyFlowProps {
  flowType: 'isee' | 'permesso' | 'spid' | 'codiceFiscale' | 'firstPermesso' | 'tesseraSanitaria' | 'cartaIdentita' | 'prenotazioneVisita' | 'medicoBase' | 'anagrafe' | 'patente' | 'universita' | 'dsu' | 'onlineCaf';
}

const getFlowChecklists = (flowType: string, t: (key: string) => string) => {
  const checklists = {
    isee: [
      t('isee_item_1'),
      t('isee_item_2'),
      t('isee_item_3'),
      t('isee_item_4'),
      t('isee_item_5'),
      t('isee_item_6'),
    ],
    permesso: [
      t('permesso_item_1'),
      t('permesso_item_2'),
      t('permesso_item_3'),
      t('permesso_item_4'),
      t('permesso_item_5'),
      t('permesso_item_6'),
    ],
    spid: [
      t('spid_item_1'),
      t('spid_item_2'),
      t('spid_item_3'),
      t('spid_item_4'),
      t('spid_item_5'),
    ],
    codiceFiscale: [
      t('cf_item_1'),
      t('cf_item_2'),
      t('cf_item_3'),
      t('cf_item_4'),
    ],
    tesseraSanitaria: [
      t('tessera_item_1'),
      t('tessera_item_2'),
      t('tessera_item_3'),
      t('tessera_item_4'),
    ],
    cartaIdentita: [
      t('carta_item_1'),
      t('carta_item_2'),
      t('carta_item_3'),
      t('carta_item_4'),
    ],
    prenotazioneVisita: [
      t('prenotazione_item_1'),
      t('prenotazione_item_2'),
      t('prenotazione_item_3'),
      t('prenotazione_item_4'),
    ],
    medicoBase: [
      t('medico_item_1'),
      t('medico_item_2'),
      t('medico_item_3'),
      t('medico_item_4'),
    ],
    anagrafe: [
      t('anagrafe_item_1'),
      t('anagrafe_item_2'),
      t('anagrafe_item_3'),
      t('anagrafe_item_4'),
    ],
    patente: [
      t('patente_item_1'),
      t('patente_item_2'),
      t('patente_item_3'),
      t('patente_item_4'),
    ],
    universita: [
      t('universita_item_1'),
      t('universita_item_2'),
      t('universita_item_3'),
      t('universita_item_4'),
    ],
    dsu: [
      t('dsu_item_1'),
      t('dsu_item_2'),
      t('dsu_item_3'),
      t('dsu_item_4'),
    ],
    firstPermesso: [
      t('firstPermesso_item_1'),
      t('firstPermesso_item_2'),
      t('firstPermesso_item_3'),
      t('firstPermesso_item_4'),
      t('firstPermesso_item_5'),
      t('firstPermesso_item_6'),
    ],
    onlineCaf: [],
  };
  return checklists[flowType as keyof typeof checklists] || [];
};

export default function BureaucracyFlow({ flowType }: BureaucracyFlowProps) {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const { toast } = useToast();
  const [isGuideModalOpen, setIsGuideModalOpen] = useState(false);

  const [flowData, setFlowData] = useState<FlowData>(() => ({
    title: t(`${flowType}Title`),
    items: getFlowChecklists(flowType, t).map((text, index) => ({
      id: `${flowType}-${index}`,
      text,
      completed: false,
    })),
  }));

  // Update checklist items when language changes
  useEffect(() => {
    setFlowData(prev => ({
      ...prev,
      title: t(`${flowType}Title`),
      items: getFlowChecklists(flowType, t).map((text, index) => ({
        id: `${flowType}-${index}`,
        text,
        completed: prev.items[index]?.completed || false,
      })),
    }));
  }, [language, flowType, t]);

  const toggleItem = (id: string) => {
    setFlowData(prev => ({
      ...prev,
      items: prev.items.map(item =>
        item.id === id ? { ...item, completed: !item.completed } : item
      ),
    }));
  };

  const handleAddReminder = () => {
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 7);
    
    const reminders = JSON.parse(localStorage.getItem('reminders') || '[]');
    reminders.push({
      id: Date.now().toString(),
      title: flowData.title,
      dueDate: dueDate.toISOString(),
      category: flowType,
    });
    localStorage.setItem('reminders', JSON.stringify(reminders));
    
    toast({
      title: t('addReminder'),
      description: `${flowData.title} - ${dueDate.toLocaleDateString()}`,
    });
  };

  const completedCount = flowData.items.filter(item => item.completed).length;
  const progress = flowData.items.length > 0 ? Math.round((completedCount / flowData.items.length) * 100) : 0;

  // Special handling for Online CAF (Coming Soon)
  if (flowType === 'onlineCaf') {
    return (
      <Card className="hover-elevate" data-testid={`card-flow-${flowType}`}>
        <CardHeader>
          <CardTitle className="text-lg">{flowData.title}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-8">
          <div className="text-4xl mb-4">🕒</div>
          <p className="text-lg font-medium text-muted-foreground">{t('comingSoon')}</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="hover-elevate" data-testid={`card-flow-${flowType}`}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{flowData.title}</CardTitle>
            <CardDescription className="mt-1">
              {completedCount}/{flowData.items.length} {t('completed')}
            </CardDescription>
          </div>
          <Badge variant="secondary" className="ml-2">
            {progress}%
          </Badge>
        </div>
        <div className="w-full bg-muted rounded-full h-2 mt-4">
          <div
            className="bg-primary h-2 rounded-full transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {flowType === 'codiceFiscale' && (
          <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
            <p className="text-sm text-foreground">
              {t('codiceFiscaleNote')}
            </p>
          </div>
        )}

        <div className="space-y-3">
          {flowData.items.map((item) => (
            <div key={item.id} className="flex items-center gap-3">
              <Checkbox
                id={item.id}
                checked={item.completed}
                onCheckedChange={() => toggleItem(item.id)}
                data-testid={`checkbox-${item.id}`}
              />
              <label
                htmlFor={item.id}
                className={`text-sm cursor-pointer flex-1 ${
                  item.completed ? 'line-through text-muted-foreground' : ''
                }`}
              >
                {item.text}
              </label>
            </div>
          ))}
        </div>

        <div className="flex flex-col gap-2">
          {guideFileMapping[flowType] && (
            <Button
              variant="default"
              className="w-full gap-2 bg-cyan-600 hover:bg-cyan-700 text-white"
              onClick={() => setIsGuideModalOpen(true)}
              data-testid={`button-guide-${flowType}`}
            >
              <BookOpen className="h-4 w-4" />
              {language === 'tr' ? 'Nasıl Başvurulur' : language === 'it' ? 'Come Applicare' : 'How to Apply'}
            </Button>
          )}

          <Button
            variant="secondary"
            className="gap-2"
            onClick={handleAddReminder}
            data-testid={`button-add-reminder-${flowType}`}
          >
            <Bell className="h-4 w-4" />
            {t('addReminder')}
          </Button>

          {flowType === 'isee' && (
            <CafBooking universityKey="polimi" />
          )}

          {flowType === 'permesso' && (
            <PermessoBooking />
          )}

          {flowType === 'codiceFiscale' && (
            <CodiceFiscaleBooking />
          )}

          {flowType === 'firstPermesso' && (
            <Button
              variant="default"
              className="gap-2"
              onClick={() => {
                const url = 'https://www.prenotafacile.poliziadistato.it/';
                const opened = window.open(url, '_blank');
                if (!opened) {
                  navigator.clipboard.writeText(url);
                  toast({
                    title: t('popupBlocked'),
                    description: url,
                  });
                }
              }}
              data-testid="button-check-appointment"
            >
              {t('checkAppointment')}
            </Button>
          )}
        </div>
      </CardContent>

      {guideFileMapping[flowType] && (
        <GuideModal
          isOpen={isGuideModalOpen}
          onClose={() => setIsGuideModalOpen(false)}
          title={flowData.title}
          guideFile={guideFileMapping[flowType]!}
          language={language}
        />
      )}
    </Card>
  );
}
