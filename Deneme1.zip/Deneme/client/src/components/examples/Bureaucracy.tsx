import { LanguageProvider } from '@/contexts/LanguageContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { Toaster } from '@/components/ui/toaster';
import Bureaucracy from '../../pages/Bureaucracy';

export default function BureaucracyExample() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <Bureaucracy />
        <Toaster />
      </LanguageProvider>
    </ThemeProvider>
  );
}
