import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslation } from '@/lib/i18n';
import { PERMESSO_CITIES, PERMESSO_GUIDE, type PermessoCity } from '../../../config/permesso';
import { MapPin, BookOpen, Calendar } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function PermessoBooking() {
  const { language } = useLanguage();
  const t = useTranslation(language);
  const isRTL = language === 'ar';
  const { toast } = useToast();

  const [locationsOpen, setLocationsOpen] = useState(false);
  const [howToOpen, setHowToOpen] = useState(false);
  const [bookOpen, setBookOpen] = useState(false);
  const [selectedCity, setSelectedCity] = useState<string>('');

  const openLinkInNewTab = (url: string) => {
    // Attempt to open with window.open first (direct user gesture)
    const newWindow = window.open(url, '_blank', 'noopener,noreferrer');
    
    // If popup blocked (returns null), use anchor fallback
    if (!newWindow) {
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.target = '_blank';
      anchor.rel = 'noopener noreferrer';
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
    }
    
    // Show user feedback
    toast({
      title: t('linkOpened'),
      duration: 3000,
    });
  };

  const handleCityClick = (city: PermessoCity, e: React.MouseEvent) => {
    e.stopPropagation();
    openLinkInNewTab(city.url);
    setLocationsOpen(false);
  };

  const handleBookAppointment = () => {
    if (selectedCity) {
      const city = PERMESSO_CITIES.find((c: PermessoCity) => c.key === selectedCity);
      if (city) {
        openLinkInNewTab(city.url);
        setBookOpen(false);
        setSelectedCity('');
      }
    }
  };

  const guideContent = PERMESSO_GUIDE[language] || PERMESSO_GUIDE.en;

  return (
    <div className={`flex flex-wrap gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
      {/* Button 1: Appointment Locations */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => setLocationsOpen(true)}
        className="gap-2 shrink-0"
        data-testid="button-permesso-locations"
      >
        <MapPin className="w-4 h-4" />
        <span>{t('permessoLocations')}</span>
      </Button>

      {/* Button 2: How to Get Appointment */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => setHowToOpen(true)}
        className="gap-2 shrink-0"
        data-testid="button-permesso-howto"
      >
        <BookOpen className="w-4 h-4" />
        <span>{t('permessoHowTo')}</span>
      </Button>

      {/* Button 3: Book Appointment */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => setBookOpen(true)}
        className="gap-2 shrink-0"
        data-testid="button-permesso-book"
      >
        <Calendar className="w-4 h-4" />
        <span>{t('permessoBook')}</span>
      </Button>

      {/* Modal 1: Appointment Locations */}
      <Dialog open={locationsOpen} onOpenChange={setLocationsOpen}>
        <DialogContent dir={isRTL ? 'rtl' : 'ltr'} data-testid="dialog-permesso-locations">
          <DialogHeader>
            <DialogTitle>{t('permessoLocations')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 max-h-[60vh] overflow-y-auto">
            {PERMESSO_CITIES.map((city: PermessoCity) => (
              <div
                key={city.key}
                className={`flex items-center gap-3 p-3 rounded-md border ${isRTL ? 'flex-row-reverse' : ''}`}
                data-testid={`permesso-city-item-${city.key}`}
              >
                <div className="flex-1">
                  <div className="font-medium text-foreground">{city.name}</div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={(e) => handleCityClick(city, e)}
                  className="gap-2 shrink-0"
                  data-testid={`button-open-${city.key}`}
                >
                  {isRTL && <span>{t('openCaf')}</span>}
                  {!isRTL && <span>{t('openCaf')}</span>}
                </Button>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal 2: How to Get Appointment */}
      <Dialog open={howToOpen} onOpenChange={setHowToOpen}>
        <DialogContent dir={isRTL ? 'rtl' : 'ltr'} className="max-w-2xl" data-testid="dialog-permesso-howto">
          <DialogHeader>
            <DialogTitle>{t('permessoHowTo')}</DialogTitle>
          </DialogHeader>
          <div className="prose prose-sm dark:prose-invert max-h-[60vh] overflow-y-auto">
            <div className="whitespace-pre-wrap text-sm">{guideContent}</div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal 3: Book Appointment */}
      <Dialog open={bookOpen} onOpenChange={setBookOpen}>
        <DialogContent dir={isRTL ? 'rtl' : 'ltr'} data-testid="dialog-permesso-book">
          <DialogHeader>
            <DialogTitle>{t('permessoBook')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">
                {t('selectCity')}
              </label>
              <Select value={selectedCity} onValueChange={setSelectedCity}>
                <SelectTrigger data-testid="select-city-trigger">
                  <SelectValue placeholder={t('selectCity')} />
                </SelectTrigger>
                <SelectContent>
                  {PERMESSO_CITIES.map((city: PermessoCity) => (
                    <SelectItem key={city.key} value={city.key} data-testid={`select-city-${city.key}`}>
                      {city.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={handleBookAppointment}
              disabled={!selectedCity}
              className="w-full"
              data-testid="button-confirm-booking"
            >
              {t('openCaf')}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
